# Follow-up studies

[RFC 0001 is implemented](./docs/implementation/rfc-0001.md), with the [reviewed results](./RESULTS.md) and complete evidence published locally.

The remaining investigation ideas are separate studies: trace PowerSync readiness and upload scheduling, test the Rust attachment-readiness hypothesis, separate Zero materialization from application aggregation, and collect a repeated browser performance campaign. Each needs a declared configuration and independent trials; none should silently replace failures in this publication.

Historical reports and investigations remain in [the September 5 archive](./results/history/2026-09-05/README.md).
