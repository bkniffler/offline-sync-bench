# Reproducing the benchmark source

Every new campaign writes `SOURCE.json` before starting its first trial. The archive contains the exact source file bytes, executable modes, internal symlinks and deleted paths, including uncommitted changes. Its checksum is recorded in the manifest. This supplements the revision and dirty flag, which alone cannot reconstruct a modified checkout.

Source identity uses file bytes rather than decoded text. File content or mode changes invalidate a running campaign. The publication command verifies both the archive checksum and each file's checksum before including the snapshot with the report.

Restore a local campaign into a new directory:

```sh
bun run src/restore-source.ts --manifest .results/<campaign>/CAMPAIGN.json --out /tmp/restored-benchmark
```

For a published report, pass its `RESULTS.json` and the linked source archive:

```sh
bun run src/restore-source.ts --manifest /path/to/RESULTS.json --snapshot /path/to/SOURCE.json --out /tmp/restored-benchmark
```

The destination must not exist. Restoration verifies the resulting file inventory against the campaign hash. It does not overwrite a checkout or recreate deleted files. The archive is JSON; regular-file contents are base64-encoded so binary assets survive exactly.

This restores benchmark source, not installed packages, compiled native binaries, container images or database volumes. Install the lockfile-pinned dependencies and use the campaign's recorded runtime, image and workload configuration when reproducing measurements. The source archive and original manifest should remain together.

## Rust executable identity

Campaigns that include Syncular Rust now run a locked release build before capturing their source snapshot. The manifest records the executable's resolved path, byte count, mode and SHA-256, plus the Cargo and compiler executables, versions, build command and Cargo input hashes. The build must start and finish under the same benchmark source fingerprint. Cargo's [JSON artifact output](https://doc.rust-lang.org/cargo/reference/external-tools.html) identifies the executable actually produced, including a configured target directory.

Rustup proxies are resolved to the selected Cargo executable before hashing and invocation. The build recipe passes the selected concrete compiler to Cargo and disables compiler wrappers explicitly. Cargo documents these [environment overrides](https://doc.rust-lang.org/cargo/reference/environment-variables.html). Cargo configuration is recorded as described below. The [fresh build-input record](./implementation/rust-build-inputs.md) now covers dependency sources, selected native tools and SDK contents, with a controlled environment and clean output directory. It does not claim a hermetic OS image.

The controller verifies executable and build-tool hashes between trials. Each Rust trial verifies the executable checksum before and after measurement and reports that identity. Launches use a cheap file identity, mode, size and timestamp check so full hashing stays outside measured operations. Publication requires the trial identity and archived build inputs to match the manifest.

`SYNCULAR_RUST_BENCH_BIN` can select a custom binary for development or diagnostic campaigns. Its compiler remains unknown, and it cannot enter a publication campaign without verified build provenance. A missing custom path fails instead of silently falling back to another executable. The compiled binary itself is not included in `SOURCE.json`.

## Installed host dependencies

New campaigns write `DEPENDENCIES.json` with checksums for installed host package files, including native addons, plus file modes, directory entries and symlink targets. Missing symlink targets remain explicitly missing. Direct dependency versions must match the exact root manifest pins. Existing host `node_modules` directories beside archived package manifests are included; container dependencies remain identified by their image bytes.

The controller captures the installation before the campaign and rehashes it before and after each trial. A changed file, mode, target or file inventory invalidates the campaign. Hashing happens outside measured child processes. It adds campaign time and reads package files into the OS cache; these runs do not establish cold filesystem-cache startup. The current installation contains about 1.97 GB across 119,122 files, and a full capture took about 15 seconds during development.

Publication requires the inventory to match the archived root package manifest and result comparison profiles. It verifies the inventory artifact before writing the report, then includes it at `results/dependencies/<fingerprint>/DEPENDENCIES.json`. Older campaigns without this evidence remain historical records and cannot satisfy the new publication gate.

After restoring the archived source and installing its dependencies, verify the installation:

```sh
bun run src/dependencies.ts --manifest /path/to/CAMPAIGN.json --root /path/to/restored-benchmark
```

A published `RESULTS.json` also works when its linked dependency inventory is present. The command verifies the artifact and rehashes the specified installation.

The inventory records identity, not package contents. Reproduction still requires installing the dependencies and comparing their installed bytes; a lockfile alone cannot recreate an unarchived local package patch. This implementation rejects dependency links outside its captured installation roots and requires concrete dependency-root directories. External native build inputs still require additional provenance work.


## Runtime and service configuration

New campaigns write `CONFIGURATION.json` before the first trial and compare its fingerprint before and after every trial and at campaign completion. The record covers relevant benchmark, product, runtime and build-tool environment families, common locale/proxy/temp/library settings, root dotenv files, the selected Docker context endpoint, resolved Compose configuration, inspected container settings and bind-mounted file contents and modes. The environment passed to the trial includes the campaign's effective client-count override and selected executable settings.

Readable entries retain numeric and common enum settings. Other environment values and command arguments are represented by equality fingerprints rather than plaintext. These hashes allow change detection; they do not provide encryption or enough information to reconstruct credentials. Generated process IDs and executable guard receipts are excluded. Ordinary container state, uptime and health transitions do not change the fingerprint, while resource limits, environment, command and configuration changes do. Container recreation can change identity even when its declared Compose service is unchanged.

Bind-mounted inputs are hashed recursively; symlinks are rejected until their targets have explicit input coverage. Named database volume contents remain outside configuration identity because workloads mutate them. Physical database state still needs separate normalization or evidence. `DOCKER_HOST` overrides are recorded independently of the selected Docker context; the context endpoint alone does not establish the effective connection destination.

Publication requires the configuration artifact, verifies its checksum and source binding, and copies it to `results/configurations/<fingerprint>/CONFIGURATION.json`. Comparison profiles include its fingerprint. The [native smoke](../results/diagnostics/configuration-provenance-smoke/VERIFICATION.json) verifies complete offline data alongside source, installed dependencies and configuration bindings. A [controlled CPU-cap change](../results/diagnostics/configuration-change-guard/VERIFICATION.json) invalidated a correct native workload. The initial zero-cap cleanup failed; verified restoration required recreating the stateless service, whose new identity remains distinct. This scoped record does not establish a hermetic runtime or build: undeclared application environment inputs, external native libraries and SDKs remain limitations.


## Cargo configuration inputs

Source-built Rust campaigns now record the Cargo configuration hierarchy inside `executables.rustDriver.build.configuration`. Capture runs before the build; guards compare it after the build and between trials. The record includes file hashes, modes, resolved symlink targets, missing-file probes, include order, merged file-setting fingerprints and the complete inherited build-environment fingerprint. Credentials and opaque values remain hashed rather than published as plaintext.

The resolver follows Cargo's [configuration hierarchy and include rules](https://doc.rust-lang.org/cargo/reference/config.html): crate and ancestor files override home defaults, the extensionless file wins when both names exist, and included files merge before their parent. Tests cover nested includes, arrays, optional files, changed link targets and new ancestor configuration. A native check confirms that the installed Cargo 1.96 applies an included target directory.

Merged file settings and inherited environment are recorded separately. Cargo still interprets environment precedence, relative paths, flags and target-dependent settings; this record does not claim to list every final compiler argument. The [native Rust smoke](../results/diagnostics/cargo-configuration-smoke/VERIFICATION.json) validates the configuration alongside exact source, compiler, driver, installed host dependencies and offline data. Its search found no active config files across 14 candidate paths. A [controlled file addition](../results/diagnostics/cargo-configuration-change-guard/VERIFICATION.json) invalidated a correct native trial; removing the file and directory restored the complete fingerprint with unchanged driver/compiler identities. Publication requires the source-bound build configuration record, including for an otherwise unchanged driver.

These fingerprints identify inputs without storing their plaintext contents. Reproducing a customized build requires restoring the original config files and environment separately. The separate `RUST-BUILD.json` artifact covers Cargo source bytes and the selected native toolchain/SDK inventory. The [fresh-build smoke](../results/diagnostics/rust-build-inputs-smoke/VERIFICATION.json) verifies that record against an actual newly built driver and native results.
