# Packet impairment needs a verified packet boundary

The [transport calibration](../../results/diagnostics/network-emulator-calibration/VERIFICATION.json) verifies a private-link forwarding path on the recorded OrbStack host. Five established TCP echoes per condition produced median round trips of 0.261, 105.826 and 0.267 ms with 0, 50 and 0 ms configured in each direction. The 105.6 ms added round trip passes the predeclared 80–140 ms calibration range.

Three 1 MiB echo transfers with 5% random loss and seeds 42, 43 and 44 delivered every byte. The six directional loss observations range from 3.73% to 5.32%, within the predeclared 3–7% check. Each direction counted at least 1,008 packets, with no oversized packets in the forwarding audit. Independently decoded captures contain repeated TCP payload sequence ranges and no IPv4 packet larger than 1,500 bytes. These are transport checks, not product performance results.

## Why the first implementations were insufficient

The single-router prototype passed its original checks: complete payloads, some drops, repeated sequence ranges, and a small maximum packet in its outbound capture. Those checks did not establish the unit of loss. Linux can carry multiple eventual packets in one buffer through [segmentation offload](https://kernel.org/doc/html/latest/networking/segmentation-offloads.html). The upstream [netem implementation](https://github.com/torvalds/linux/blob/master/net/sched/sch_netem.c) makes its ordinary loss decision on the enqueued buffer; a capture after segmentation cannot prove that each eventual packet had an independent drop decision.

The stronger two-router bridge probes recorded oversized buffers before impairment despite disabled TSO, GSO and GRO. Disabling additional checksum and list offloads did not remove them. These failures remain archived. The bridge's precise aggregation or preservation mechanism has not been isolated.

The accepted prototype connects the two owned router namespaces with a private veth pair. Each direction crosses an unshaped hop with offloads disabled before the peer applies netem to the forwarded packets. Bypassing the container bridge for this intermediate hop eliminated oversized buffers in the audited probe. Both directions retain native TCP retransmission; no application chunks are discarded by a proxy.

The initial private-link setup failed while opening the peer namespace. The helper initially held fewer capabilities than that peer. Giving it the same `NET_ADMIN` and `NET_RAW` capabilities allowed setup; the helper sees only the two owned containers' namespaces and removes itself after creating the link. All five probes' owned containers and networks are verified absent, including the automatically removed helper that the failed script could no longer inspect.

## Connection setup is a separate measurement

Under added delay, the host reported a TCP connection in under a millisecond, but the first echo took roughly 210 ms. A second echo on the same connection took roughly 106 ms. Consequently, the first echo cannot be labeled established round-trip latency. The profile retains host port forwarding and `host.docker.internal`; it does not establish physical WAN behavior or an uninterrupted host-to-service TCP connection. The archive records the actual host provider, kernel, image, packages, namespace configuration and timing boundaries.

The forwarding capture initially ended before buffered capture data reached the output file. Immediate capture mode repaired that diagnostic path. The accepted archive checks capture termination, packet counts, kernel capture drops and raw PCAP decoding, rather than relying only on a capture file's existence.

## Integration requirements

The reusable implementation is [the packet network module](../../src/network/emulator.ts). It accepts immutable Docker image IDs, preserves HTTP/WebSocket URL paths, groups routes to the same host port, records namespace configuration and packet counters, and verifies ownership before cleanup. Its packet audit also checks the selected route counters so buffers above the length rule's 65,535-byte bound cannot disappear from accounting.

The [module smoke](../../results/diagnostics/network-emulator-module/VERIFICATION.json) passes HTTP upload/download, a separate application route and WebSocket echo with 50 ms each way at both 0% and 5% loss. Both HTTP paths return the exact 1 MiB payload; both WebSocket paths return the exact 16 KiB payload. Applied configuration, endpoint bindings, packet-size counters and cleanup are verified at source `eacf3767178522c8ef28f60102233933653e89c35e45798a64cb5a4b60c19f92`. Six deliberately altered evidence records are rejected. The full suite passes 153 tests (929 assertions across 44 files), with TypeScript and whitespace checks.

Native collaboration integration now binds this evidence to each trial and separates client routes from fixture administration. The [eight-adapter latency campaign](../../results/diagnostics/network-collaboration-latency/VERIFICATION.json) completes at 50 ms each way. The [forced-timeout probe](../../results/diagnostics/network-trial-timeout/VERIFICATION.json) verifies that the measured process group and owned network objects are gone after a three-second deadline. These archives preserve the earlier Electric acknowledgment boundary, which is [ineligible for revised acceptance comparisons](./electric-collaboration-acknowledgment.md). Redirects, presigned attachment URLs, IPv6 and undeclared service discovery endpoints are not covered by this module. Loss seeds identify the random stream; they do not guarantee identical drop positions when SDK packet ordering changes. A common outage/restoration policy and the retry-phase experiment remain separate requirements before publication.

## Native loss exposes a replica-setup limit

The [1% loss campaign](../../results/diagnostics/network-collaboration-loss/VERIFICATION.json) completes seven of eight collaboration attempts at the same source as the latency campaign. Turso reaches the predeclared 900-second trial deadline during initial writer-replica setup. Actual drops, exact routes, packet sizes and cleanup are verified, and the timeout remains in the coverage record. This single attempt cannot estimate loss variability.

The [partial-store record](../../results/diagnostics/network-collaboration-loss/TURSO-PARTIAL-STORE.json) preserves the writer file identity and checksum after termination: 223,817,728 logical bytes and 124,825,600 allocated bytes. A live observation records about 72 MB of return traffic before the deadline. File length does not establish complete download or valid materialization. The zero-loss attempt completed in 59.1 seconds and counted about 470 MB at the return-path queue; that counter includes the measured forwarding scope and retransmissions.

The earlier [physical-state experiment](./turso-startup-physical-state.md) motivates checking retained database state, but it does not isolate the cause of this timeout. A controlled fresh/retained and zero/loss experiment is needed to separate physical transfer volume from transport recovery. No causal speed claim follows from the two integration attempts.
