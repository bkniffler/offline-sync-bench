# Fixture preparation changed the measured environment

The server-storage checks exposed two setup problems in the [development campaign](../../results/diagnostics/server-storage-development/VERIFICATION.json). PowerSync's collaboration runner recreated containers and volumes during its trial. Turso's reset of a million-task fixture crashed its admin process. Both affect whether the harness can establish a valid comparison before client timing begins.

## PowerSync recreated its stack during a trial

The native collaboration operation returned correct results, but every one of its five container IDs changed. Both application image IDs also changed. The measured runner unconditionally invoked Compose with a build, then deleted and recreated volumes when `resetFirst` was true. The [raw attempt](../../results/diagnostics/server-storage-development/0015-powersync-online-propagation.json) preserves the before/after inventory, and the source archive preserves the rebuild calls.

The campaign stopped at that identity mismatch. Thirteen native outcomes completed, two Turso attempts failed and one planned case remained unrun. PowerSync's native output is retained, but its changed environment is ineligible for publication.

Provisioning now belongs to the parent harness. The PowerSync worker checks readiness and resets the logical fixture through the admin API. It no longer builds images, recreates containers or deletes volumes. Startup and other shared controllers already use logical fixture preparation. All sixteen attempts in the [final startup/collaboration campaign](../../results/diagnostics/server-storage-smoke/VERIFICATION.json) pass with stable configured service and storage identities.

## Turso pushed one million deletions as one transaction

After the extended startup campaign, Turso's admin held a million-task fixture. Its reset deleted every table in one transaction and then called `push()`. The following collaboration setup lost its HTTP connection; Docker logged a fatal V8 invalid-size allocation in the native sync binding, with exit code 133 and no OOM-kill flag.

The [isolated native experiment](../../results/diagnostics/turso-reset-native/VERIFICATION.json) reproduced that operation boundary. The reset committed locally with all task rows removed and 1,000,009 CDC operations. The process then failed during `push()` while creating a roughly 253-million-element native-to-JavaScript array. No reset-push completion was observed.

The configured 2,000-operation push threshold could not make this transaction smaller. The pinned [0.7.2 sync API](https://docs.rs/crate/turso_sync_sdk_kit/0.7.2/source/turso_sync.h) specifies batching between transactions while keeping each transaction intact. The harness therefore has to bound the deletion transactions themselves.

A second isolated fixture used committed batches of at most 2,000 deleted rows, each followed by a native push. It completed 504 batches across all five tables, seeded the replacement 1,000 tasks and passed full task/screen validation in a fresh native client. The production reset now follows this verified path. This changes fixture setup; it does not weaken transaction guarantees in measured application operations.

The failed original admin replica could not restart successfully because its giant reset remained queued. Its five files were moved into a diagnostic directory within the same volume, with SHA-256 checks before and after the move. Provisioning retained the named server/admin volumes and created a new admin replica. Service containers and images were rebuilt before the new campaign recorded its configuration. The preserved files remain included in the admin volume's allocation, so that counter also includes inactive diagnostic data.

These are correctness and harness-isolation findings, not product speed rankings. The experiment preserves the native failure, the bounded variant, complete replacement data, source/dependency/configuration identities and cleanup receipts. The final native startup/collaboration campaign validates the repaired production paths together.


## Matching row totals hid a previous screen fixture

The [PowerSync screen regression](../../results/diagnostics/powersync-storage-development/VERIFICATION.json) passed the relationship case, then rejected the local-query case. The runner had observed its expected 100,000 tasks, but task 3 still belonged to `org-1-user-3`; the new local fixture requires `org-1-user-1`. Both screen fixtures have the same total. The first-sync and count checks therefore did not establish that the intended replacement data was ready.

Screen preparation now waits up to the existing 120-second limit for exact canonical tasks and the related data required by the case. It records checks and validation mismatches outside query timing. Full query-output validation still runs independently. This corrects the harness readiness condition; it does not establish a defect in PowerSync replication.

A [follow-up native probe](../../results/diagnostics/powersync-fixture-probe/VERIFICATION.json) observed partial relationship data after first sync and then verified both complete fixtures. Its local-query snapshot was already correct, so that probe did not reproduce the same-count mismatch. The original rejected attempt remains the evidence for that failure. The [corrected adapter regression](../../results/diagnostics/powersync-storage-regression/VERIFICATION.json) passes two randomized blocks of both screen cases, including both fixture transition directions. All four attempts retain exact readiness digests, independently validated query outputs and stable service identities. This correctness regression does not establish a cross-product latency comparison.
