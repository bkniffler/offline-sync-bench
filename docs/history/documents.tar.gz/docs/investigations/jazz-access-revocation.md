# Jazz filters revoked data but retains local records

The canonical Jazz 2.0.0-alpha.53 access test reaches its 60-second purge deadline in both modes. Online queries hide the revoked project's tasks while the same local store retains them. After a network outage, the existing client's visible result also remains stale. Fresh clients receive correctly scoped data.

The [verified campaign](../../results/diagnostics/jazz-access-smoke/VERIFICATION.json) preserves the failures and excludes them from latency comparisons. Jazz startup and collaboration, plus the three Syncular controls, pass at the same source. Both additional [100k local-screen regressions](../../results/diagnostics/jazz-access-screen-regression/VERIFICATION.json) also pass.

| Mode at the purge deadline | Existing client: visible / raw task records | Fresh affected / unaffected client |
| --- | --- | --- |
| Online | 500 / 1,000 | 500 / 1,000 |
| Offline, then network restored | 1,000 / 1,000 | 500 / 1,000 |

Each mode uses the shared two-project fixture, independent native client processes and an isolated dataset. Native local-first tokens map the two benchmark actors to distinct authenticated subjects. A deployed policy derives task access from project membership. The affected client subscribes to its tasks and memberships, with the compiled policy bundle loaded locally.

The administrative client deletes one membership and receives native edge acceptance. Complete server snapshots preserve every task and the other three memberships. The affected SQLite path, device and inode remain unchanged. Its raw local query runs without a session and with local-only propagation, independently of the session-scoped query and maintained subscription. All three views retain complete records for inspection; counts alone do not qualify the result.

For the offline case, the shared TCP gate closes established connections and refuses new ones. Both traffic directions remain unchanged through revocation and the offline snapshot. Restoring the route leaves reconnect handling to the native transport. The test preserves the final cache at timeout, then checks both fresh actors. Client resource samples cover only the affected process and its descendants.

These are confirmed observations; the internal retention and reconnect mechanisms remain unexplained. Jazz documents distinct [server and local policy enforcement](https://jazz.tools/docs/auth/permissions), which does not by itself establish removal of previously received records. Next, trace membership delivery and subscription restoration, then test whether re-establishing subscriptions changes the visible result while preserving the store. Any explicit recovery strategy needs its own profile.

For an application that requires local task removal after revocation, this tested native configuration does not meet the benchmark contract. Fresh-client filtering and hidden query results cannot establish that outcome. The result does not measure forensic erasure or removal of copied data.

The [initial development campaign](../../results/diagnostics/jazz-access-development/VERIFICATION.json) failed before revocation: Jazz stored the new schema but withheld permissions because the membership-table migration was missing. The harness now publishes that additive migration and requires a matching policy head before seeding. This follows Jazz's [deployment sequence](https://jazz.tools/docs/schemas/migrations). The original receipts and empty actor snapshots remain archived.

Earlier [isolated diagnostics](../../results/diagnostics/jazz-access-native/VERIFICATION.json) retain revoked records even when raw inspection is deferred for 60 seconds. Those minimal-schema, single-process experiments support further investigation but remain separate from the canonical campaign. Neither supplies a cross-product performance ranking.
