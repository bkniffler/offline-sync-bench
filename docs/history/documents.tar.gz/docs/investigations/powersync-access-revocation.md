# PowerSync revocation needs a membership-scoped profile

PowerSync's original benchmark rules gave every client the global fixture. Deleting an application membership could not establish read revocation under those rules. The access case now uses a signed access-only grant whose project buckets come from the source membership table. Ordinary workload clients retain a separate global grant.

This follows PowerSync's supported [membership parameter-query pattern](https://docs.powersync.com/sync/rules/parameter-queries). The pinned service validates the actual mounted rules, and membership changes are included in the source publication. The benchmark token issuer supplies the declared actor identity; the test measures read scope under that identity, not a production login system.

The [native campaign](../../results/diagnostics/powersync-access-smoke/VERIFICATION.json) verifies both modes:

| Check | Observed outcome |
| --- | --- |
| Online revoke | The original client removes exactly the revoked project's 500 tasks |
| Revoke while offline | All 1,000 original tasks remain readable, with no incoming response bytes |
| Reconnect | The original client retains exactly the other project's 500 tasks |
| Fresh revoked actor | Receives only the retained project's 500 tasks |
| Fresh unaffected actor | Still receives all 1,000 tasks |

Every row is checked against the canonical fixture. The affected process, SQLite path, device and inode remain unchanged across revocation. The application neither deletes local task rows nor replaces the cache. The fresh-actor checks distinguish removal of access from deletion of shared server data.

This evidence confirms native removal from the active replica in the tested configuration. It does not establish erasure of copies elsewhere or write authorization. Reconnect timing includes the SDK's retry behavior, observation and IPC; the single smoke trial does not isolate their contributions or support a performance ranking. PowerSync's continuous-sync profile is therefore recorded separately from explicit-sync and application-refresh profiles.

The same campaign also passes PowerSync's global startup/collaboration checks and the three Syncular controller controls. Raw results, source/dependency/configuration identities, resource samples, storage boundaries, grant fields and the structured explanation remain in the [campaign archive](../../results/diagnostics/powersync-access-smoke/CAMPAIGN.json).
