# Turso startup depends on storage history

A controlled experiment loaded the same correct 1,000-task fixture from fresh storage and from storage that previously held 100,000 tasks. The retained condition transferred **74.1 times as many response bytes** and took longer in every pair. Logical task count alone does not describe the startup workload in this tested Turso configuration.

![Turso fresh and retained storage: response bytes and paired full-data startup timings](../../results/diagnostics/turso-physical-pairs/physical-state.svg)

## What the experiment establishes

Three predeclared pairs used fresh/retained, retained/fresh and fresh/retained execution order. Each preparation used new isolated server/admin containers and volumes, with the same pinned images and resource limits. Fresh storage received only 1,000 tasks. Retained storage received 100,000 tasks, then the identical reset-and-seed operation down to 1,000. Each server restarted before a fresh client's startup; a second fresh client followed against the warm server.

All twelve clients passed complete task-data and ordered-screen validation under the shared 90-second observation policy. Every fresh case received 297,414 TCP response bytes; every retained case received 22,023,944. Fresh replicas had 77 pages and no free pages. Retained replicas had 5,366 pages, including 5,289 free pages. Each page was 4,096 bytes. Server database/WAL sizes and replica page statistics were collected separately, outside timing.

**Confirmed within this experiment:** changing the declared preparation history increased transfer volume and startup cost. Retained preparation added 71–96 ms to full-data availability in the three restarted-server pairs, and 79–91 ms in the warm-server pairs. The chart shows every pair; three independent preparations per condition do not support a precise population confidence interval. Cold and warm clients share a preparation and are not six independent storage-history trials.

The experiment establishes the effect of this history intervention. It does not isolate freelist size from other effects of prior writes, account for each transmitted page or millisecond, or estimate behavior on another network. TCP counters include HTTP headers but exclude TCP/IP overhead. The [structured finding](../../results/diagnostics/turso-physical-pairs/FINDING.json) binds the explanation to every measured condition. [Verification](../../results/diagnostics/turso-physical-pairs/VERIFICATION.json) covers raw snapshots, observer policy, source/dependencies/configuration, isolated resources and thirteen rejected evidence corruptions.

For application comparisons, record storage preparation alongside task counts. A logical reset did not restore fresh-database startup cost here. Publication must declare equivalent preparation rules and expose retained physical state; these diagnostic timings are not a cross-product ranking.

## Why we investigated it

The [original startup diagnostic](../../results/diagnostics/turso-startup-physical-state.json) recorded 111,912,431 response bytes in every 1k, 10k and 100k case. A fresh diagnostic replica reported 27,266 pages, including 21,895 free pages. The final server WAL frame header also reported a 27,266-page database image; the inspection did not validate every WAL frame's checksum.

The [extended startup smoke](../../results/diagnostics/startup-extended-smoke/VERIFICATION.json) then validated these complete datasets, with matching byte/page counts in cold and warm cases:

| Tasks | TCP response bytes | Replica pages | Free replica pages |
| --- | ---: | ---: | ---: |
| 1,000 | 111,912,431 | 27,266 | 27,189 |
| 500,000 | 111,912,431 | 27,271 | 0 |
| 1,000,000 | 224,295,016 | 54,648 | 0 |

The small fixture retained substantial unused capacity, while the million-task fixture required a larger replica and transfer. Post-startup replica pages are not an exact count of transferred pages. The original database's preparation history remains unknown, so the controlled experiment cannot reconstruct its 112 MB transfer or justify retroactive timing adjustments.

## Experiment setup and cleanup

The first isolated attempt failed before client initialization. Its script resolved a random published Docker port before restarting the server. A native restart probe demonstrated that Docker reassigned the port; the corrected experiment resolves it after restart. The [failed attempt and probe](../../results/diagnostics/turso-physical-development/VERIFICATION.json) remain archived with the eleven unrun clients. That attempt did not capture the attempted URL or server logs, so the probe establishes the setup defect without reconstructing each failed request.

Every experiment-owned container, volume and network was removed and its absence verified. Original benchmark services and volumes remained intact. The [raw experiment](../../results/diagnostics/turso-physical-pairs/EXPERIMENT.json) retains preparation receipts, snapshots, process identities, resource samples and cleanup evidence. Both experiments have ended.
