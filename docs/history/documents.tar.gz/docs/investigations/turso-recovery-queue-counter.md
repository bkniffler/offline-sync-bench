# Turso recovery: a nonzero CDC count need not mean pending task writes

The first recovery adapter rejected a completed push/pull because `stats().cdcOperations` remained nonzero. Direct inspection showed that the residual records described synchronization bookkeeping and a commit marker. The application task changes had drained. This was a benchmark counter interpretation error; the observation alone did not establish lost or undelivered writes.

In the ten-write diagnostic, the offline log contained ten task updates and ten commit markers. The raw counter moved from 20 before push to 1 after push and 2 after pull. The post-pull log contained one update to `turso_sync_last_change_id` and one commit marker, with no task changes. The [diagnostic evidence](../../results/diagnostics/turso-recovery-queue-counter.json) preserves the failed measurement and subsequent validation.

The adapter now checks retained task CDC records at the declared boundaries: before upload, and after complete push/pull. It preserves the raw CDC counter and grouped log records alongside that check. Independent reader visibility and exact final task validation remain required, so an empty application log cannot hide missing writes.

This conclusion is scoped to the installed Turso Sync 0.7.2 path and this task-update workload. It does not establish a general rule that every nonzero counter is harmless. Changes to the product's log format or replay behavior require revalidation.

The versioned [engine stats implementation](https://github.com/tursodatabase/turso/blob/v0.7.2/sync/engine/src/database_sync_engine.rs#L1336) derives its count from local changes after a stored push position. That source helps interpret the counter; the grouped records and independent data checks establish the narrower benchmark correction.
