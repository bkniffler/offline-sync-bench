# Browser collaboration: native clients, with the measurement bridge visible

Electric and Zero now complete the canonical 200-task collaboration workload in real Chromium. Each attempt starts a writer and reader in separate browser processes with fresh profile directories, performs five warmups and 50 measured writes, and checks every initial and final task. The [canonical browser smoke](../../results/diagnostics/browser-collaboration-smoke/VERIFICATION.json) verifies campaign admission. These are single-trial correctness checks, not published performance comparisons.

The [development archive](../../results/diagnostics/browser-collaboration-development/VERIFICATION.json) preserves the failed first attempt, earlier successes, both fully checked probes, and separate lifecycle tests. The actual runtime identifies itself as Chrome 151.0.7922.34. Its cached installation does not establish a stable release channel.

## What the clients actually do

Electric uses the installed Shape/ShapeStream SDK and an in-memory Shape. One same-origin mutation POST supplies the acceptance receipt. There is no local durable write queue in this configuration. Zero uses its installed browser SDK, native IndexedDB, and the repository's existing title-only mutator. Both native local and server mutation promises must succeed. Configured IndexedDB alone makes no process-durability claim.

The reader arms its native subscription before the writer dispatches a mutation. It must observe the exact task and title, independently of writer acceptance. Validation binds all 55 native receipts to their operations and checks complete final records on both clients. Zero's title-only mutation preserves `server_version`; Electric's server increments it. The expected records reflect those declared implementations.

Browser code executes at the existing service origin, with no CORS or certificate bypass. This measures SDK collaboration, including the controller bridge. It does not measure a rendered UI.

## The first failure was in result transport

The first Electric attempt failed when CDP could not return an object by value. The next probe recorded `server_version` as a native JavaScript `bigint` and reproduced the same failure with a minimal object containing `2n`. Serializing that value as a decimal string succeeded. The browser bridge now uses that lossless JSON representation for integer transport.

This is a confirmed explanation of the prototype's serialization failure. It is not evidence about Electric sync speed. The original failed attempt remains archived.

## CDP contributes time to these measurements

The timer runs in the controller. It includes reader arming, write dispatch, and receipt delivery through CDP. Browser-local event times are retained separately; clocks from different processes are not subtracted.

Before and after each workload, the probe runs 100 idle calibration samples after five warmups. It sends one reader call, then a writer call that emits an immediate binding receipt. Median times to that receipt range from 0.22 to 0.26 ms across the four calibration sets. This identifies a measurable idle bridge cost. It does not establish the same cost under SDK load, with larger receipts, or on another machine. No calibration value is subtracted from workload latency.

Resource sampling includes the controller and both complete browser process trees. RSS sums can count shared pages more than once. These measurements need a separate browser comparison profile and explicit scope.

## Cleanup and admission

CDP process IDs agree with OS process identities. Both browsers inherit the controller's process group. Normal cleanup records initial and later helpers and verifies that all observed identities disappear. Separate live tests exercise a thrown browser operation and forced SIGKILL of the owned controller group; no observed browser/helper survives either case.

The original browser implementation passed 228 tests. Browser tests reject missing or altered native receipts, changed final data, reused client identities, omitted browser resource sampling, invalid calibration and incomplete helper cleanup evidence.

## Canonical campaign evidence

The six-attempt smoke passed at source `601d480d9e12fce14fc87de7de984f6a9e4d472bb34b4fe719ff68ee0db13f64`. Electric and Zero collaboration completed. Their restart cases and both Syncular browser cases reported not implemented. The harness never substituted native-host coverage.

The manifest binds 326 browser installation files (372,002,382 bytes), a 954,638-byte SDK bundle and its 274 source/dependency inputs. OS/CDP identities, complete native records, all receipts, calibration, resource scope, server storage, raw results and comparison profiles pass validation. Twenty deliberate result corruptions are rejected. Browser results are rejected from a native campaign, and this smoke is rejected for publication.

The publication artifact check relocates the browser inventory and bundle without changing their identity. Altered bundle bytes and mismatched source/dependency inputs are rejected; restoring the original bundle passes. Campaign runtime selection, provenance checks and browser/native profile separation are implemented. Other browser adapters/workloads and packet-network browser profiles remain not implemented. Repeated browser publication measurements remain outstanding. The subsequent loaded instrumentation check is described below.

The [native-host control](../../results/diagnostics/browser-native-control/VERIFICATION.json) subsequently passed Syncular, Electric and Zero at the same source. Native default selection, complete collaboration contracts, source/dependency/configuration/storage bindings and raw profiles pass. Browser and native comparison keys differ. Both campaigns are terminal and archived; neither is eligible for publication as a performance comparison.

## Loaded forwarding sensitivity

The [declared experiment](../../results/diagnostics/browser-loaded-instrumentation/DECLARATION.json) completed all twenty conditions at source `f6d23b446229ead3546f0e49c869e5150500c559446dfe349cb0e17e2cd8198b`. Each adapter has five independent buffered/forwarded pairs in randomized AB/BA order, with five warmups and fifty measured writes per condition. Both conditions use the same controller completion calls; forwarding adds live delivery of the buffered native milestones. Exact native data, receipt counts, fresh process/store identities and cleanup validate for every condition.

The [analysis](../../results/diagnostics/browser-loaded-instrumentation/ANALYSIS.json) reports the median of paired differences between trial medians. Positive differences mean forwarding took longer. Intervals resample the five independent pair differences, rather than pooling individual operations.

| Adapter and measured span | Paired difference, ms | 95% bootstrap interval, ms |
| --- | ---: | ---: |
| Electric controller completion | +0.077 | −1.138 to +0.283 |
| Electric writer acceptance | +0.100 | −0.100 to +0.200 |
| Zero controller completion | +0.224 | −2.220 to +1.615 |
| Zero writer acceptance | 0.000 | −1.350 to +1.600 |
| Zero local acknowledgment | +0.050 | 0.000 to +0.100 |

Every interval includes zero. Five pairs provide an imprecise sensitivity check; they do not establish negligible overhead or equivalence. The absolute writer-local differences are small enough that percentages can exaggerate their practical importance. Electric has no equivalent local durable acknowledgment in this configuration, so that metric remains unavailable.

This intervention measures the incremental effect of live milestone forwarding in the common diagnostic workflow. Both modes retain buffering, CDP dispatch/completion, native observation and external resource sampling. The canonical controller uses a different completion path. No estimate is subtracted from canonical timings, and these results cannot establish cross-product speed or the cost of all instrumentation. A dedicated, separately declared precision study would be needed to bound an overhead level relevant to a particular application.

The [artifact checks](../../results/diagnostics/browser-loaded-instrumentation/ARTIFACT-CHECKS.json) verify original and relocated records and reject fifteen artifact corruptions. The earlier [development smoke](../../results/diagnostics/browser-loaded-development/ARTIFACT-CHECKS.json) preserves a Zero setup failure: a completed query returned zero of the expected 200 rows. Both browser paths now wait for the exact seeded fixture before timing. The subsequent [loaded smoke](../../results/diagnostics/browser-loaded-smoke/ARTIFACT-CHECKS.json) and [canonical regression](../../results/diagnostics/browser-readiness-regression/VERIFICATION.json) pass their implemented cases. These successful checks do not establish why the earlier cache was empty.
