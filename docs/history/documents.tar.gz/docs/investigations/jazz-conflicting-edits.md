# Jazz acknowledges both writes before all clients agree on deletion

Three native-client diagnostics reproduced different views after an offline update met an accepted peer deletion. The writer retained the edited task; the peer and observer kept it deleted. Both mutations had successful native edge receipts. These receipts establish write admission, but do not establish convergence or explain the disagreement.

Each case uses a separately seeded 2,000-task dataset and three fresh Node clients with native SQLite stores. The writer edits behind a TCP gate. The peer then updates or deletes the same native row, and the observer must see that operation before the writer's network returns. Complete snapshots validate every task, including the 1,999 untouched records.

| Diagnostic | Update/update | Update/delete |
| --- | --- | --- |
| [Repeated connect calls](../../results/diagnostics/jazz-conflict-settlement/VERIFICATION.json) | Later peer title; successful receipts; three matching full snapshots | Different client views after the declared 15-second window |
| [Retained transport](../../results/diagnostics/jazz-conflict-retained-transport/VERIFICATION.json) | Same accepted peer outcome | Same disagreement across 22 observations |
| [Retained subscription](../../results/diagnostics/jazz-conflict-retained-subscription/VERIFICATION.json) | Same accepted peer outcome | Same disagreement across 20 observations |

The transport variant calls `connectTransport` once per client and lets the SDK reconnect. The subscription variant additionally keeps a full-dataset native edge subscription open across the outage. Its callback counts updates; it does not modify application rows. Neither variant resolved deletion delivery in these bounded runs. They do not establish a universal failure or rule out differences under other query configurations.

The writer's local and deferred edge views contained 2,000 tasks, including `conflict-offline-writer`. The peer and observer each had 1,999 tasks in both views, with the contested task absent. No native mutation errors were recorded. All diagnostic clients closed normally. The archives contain exact scripts, receipt identities, observations, source snapshots and dependency/configuration bindings. The [first feasibility attempt](../../results/diagnostics/jazz-conflict-receipt-development/VERIFICATION.json) is also preserved; it asserted deletion too early to distinguish an intermediate view from the later disagreement.

## Why the new receipt handling matters

Each diagnostic registers `WriteHandle.wait({ tier: 'edge' })` immediately after creating the mutation, before awaiting local durability. That gives direct evidence for a losing update even when the final row contains the peer's value. It does not fix the separate [historical receipt lookup issue after recovery](jazz-recovery-durability.md), whose cause remains unknown.

The current [Jazz internals documentation](https://jazz.tools/docs/reference/internals) describes per-column timestamp ordering, soft deletion and subscription replay after reconnect. It does not specify this exact update/delete race. The benchmark therefore distinguishes the documented update/update expectation from the application's requirement to retain an accepted deletion. The deletion case cannot establish a native policy while clients disagree.

## Consequence for the benchmark

The [canonical native campaign](../../results/diagnostics/jazz-conflicts-smoke/VERIFICATION.json) passes Jazz update/update, both Syncular conflict controls and both live replay regressions. Jazz update/delete times out at the shared 90-second observation limit with the same divergent views and successful receipts. The archive retains every final record and 3,393 resolution resource samples. The campaign exits with failure status, and the failed case contributes no successful latency result. All 127 contract/harness tests, TypeScript checking and whitespace checking pass. This verifies failure detection and evidence retention; it does not repair the disagreement.

The cause of deletion disagreement is **unexplained**. A useful next diagnostic would inspect the contested row's native deletion/history state on the server and each client, then compare an independent fresh reader. This could distinguish a missing tombstone delivery from a stale local live-row view. Neither cause is established by the current receipts or architecture description. These diagnostics provide correctness evidence for the pinned alpha configuration, not performance rankings.
