# A missing-row update needs a different acknowledgment

Electric and Electric + TanStack DB now execute the same application conflict policy: SQL UPDATE or DELETE by primary key, without a version precondition. A later-arriving update changes an existing task. It does not recreate a task that the peer deleted. This policy belongs to the benchmark application; it is not a product-wide conflict rule.

The original replay helpers expected every update to change a row. That assumption is valid for the replay fixture, where no peer deletes a task, but cannot describe an accepted zero-row update. TanStack also awaited the transaction ID through the task Shape. A transaction that changes no task supplies no changed task row to observe.

The [conflict endpoint](../../stacks/electric/app/src/conflicts.ts) now returns and persists the exact SQL disposition under the write's idempotency key:

| Operation in the declared race | Affected rows | Application version | Completion evidence |
| --- | --- | --- | --- |
| Peer updates the original task | 1 | 2 | Application receipt and native Shape visibility |
| Offline writer updates after the peer update | 1 | 3 | Application receipt and native Shape visibility |
| Peer deletes the original task | 1 | Absent | Application receipt and independently observed absence |
| Offline writer updates after peer deletion | 0 | Absent | Explicit no-op receipt and independently verified convergence |

Changed TanStack rows still require `awaitTxId`. A no-op lets the native transaction finish from the application receipt; it must then pass complete persisted/active and independent-client checks. Electric's reference application retains the SQLite outbox entry until its native Shape shows the receipt's row version or absence. Its optimistic row and outbox entry are reconciled in one SQLite transaction.

Neither adapter treats an HTTP success or an empty queue as sufficient. The shared controller keeps the writer isolated until a third client sees the peer's operation, verifies that the original queued write remains intact, and checks every remaining task on all three clients after restoration. The evidence validator binds the successful server receipt to the queued idempotency key and, for TanStack, the original native transaction.

## What this comparison establishes

The [native campaign](../../results/diagnostics/electric-conflicts-smoke/VERIFICATION.json) passes all four Electric/TanStack conflict attempts and the replay, supported restart and five-reader fanout regressions. Its fifteen attempts contain fourteen passes and one expected unsupported case. Queue ownership remains visible: Electric uses the benchmark's persistent SQLite cache/outbox; TanStack uses its native executor with a Node memory queue and persistent confirmed cache. TanStack's tested queue cannot survive process termination.

The persisted receipt also makes retry behavior auditable. Reusing a key for an identical request returns the original affected-row count and version, even after later task changes. Reusing it for a different operation is rejected. The [guarded retry probe](../../results/diagnostics/electric-conflicts-smoke/RETRY-PROBE.json) verifies sixteen identical replays and eight rejected mismatches using all eight original client receipts. Complete task and receipt tables are unchanged before and after those requests. Thirty corrupted-result checks also verify that incorrect receipts, records, identities and persistence claims cannot pass the result validator.

These cases establish one deliberately ordered application's behavior. Their matching final data cannot isolate query-engine cost or establish an overall product ranking. Ordinary replay keeps its existing requirement that each update changes a row; conflict handling does not relax that contract.
