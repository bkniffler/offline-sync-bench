# Fanout and reconnect harness corrections

Two initial two-reader checks failed because of how the harness resumed or observed delivery. They do not establish a product scaling limit or performance difference. The original results and logs are preserved in [the development archive](../../results/diagnostics/fanout-development/).

## Reopening a subscription did not catch up missed changes

In the [initial Syncular reconnect attempt](../../results/diagnostics/fanout-development/reconnect-syncular-development.json), a separate healthy witness held the complete 100-update backlog. Both disconnected readers still matched the pre-outage snapshot. After restoring their routes, the harness reopened live subscriptions and waited for local changes; observation timed out.

That resume path omitted an explicit native catch-up request. The [corrected attempt](../../results/diagnostics/fanout-development/reconnect-syncular-catchup-development.json) invokes native sync before reconnecting the subscription and passes full validation for both readers. This supports the narrower explanation that the original harness resume sequence was insufficient for the tested client configuration. It does not prove that every Syncular application must manage reconnect the same way. The source changed between development attempts, so these results cannot isolate a latency effect.

Connected fanout retains its separate contract: readers are already connected and receive a readiness marker before the measured write. No explicit harness catch-up request follows that write.

## The observer exceeded an expression-depth limit

The [initial Turso reconnect attempt](../../results/diagnostics/fanout-development/reconnect-turso-development.json) failed while preparing the observation query with `Expression tree is too large (maximum depth 100)`. The harness had joined 100 row predicates in a linear OR expression. The parser rejected that query before the observer could establish completion.

The observer now combines the same predicates in a balanced OR tree. It still checks every changed row's ID, title and version, and final validation checks all 2,000 rows. The [corrected attempt](../../results/diagnostics/fanout-development/reconnect-turso-balanced-development.json) passed for both readers. The error directly identifies a query construction problem; it cannot support a claim that Turso failed to synchronize the backlog.

These checks used two readers and one development trial. The default five- and 25-reader campaign provides separate coverage. Independent repeated trials and reviewed annotations are still required before publishing performance conclusions.

## TanStack waited for transactions that had already completed

The [extended two-reader campaign](../../results/diagnostics/extended-fanout-development/VERIFICATION.json) passed eight attempts and timed out in both TanStack fanout cases. The failure came from the harness's local outbox acknowledgment wait. The shared recovery driver originally accepted one offline write group; fanout uses an online readiness write followed by a separate measured group.

The acknowledgment predicate required the native outbox to contain every transaction the process had issued. After readiness completed, its transaction had left the outbox. The second group could never satisfy that predicate. A [direct native probe](../../results/diagnostics/extended-fanout-development/tanstack-fanout-ack-probe.json) establishes the mismatch: the first write returned, both native transaction receipts settled successfully, the outbox was empty, and all 2,000 active and persisted records matched both edits, while the second harness write remained pending. The measured source was `ea45cd12b1f3cfeea436254659cec966f8a182da1e9e3938706e9818c78b30ee`.

The online fanout writer now waits for native commit completion, including server acceptance and Electric visibility. Its timer already spans the entire write and reader delivery. Offline recovery retains its separate requirement to observe every pending serialized transaction while disconnected. No isolated local-commit latency is claimed for the fanout write.

All three probe attempts are preserved. The first reached its 30-second limit without phase evidence. The second recorded the native mismatch and removed its temporary store but remained alive after cleanup. The final probe explicitly exits after native close and cleanup, matching the benchmark worker lifecycle, and its controller observed exit code zero. The probe explains the harness acknowledgment failure; it does not establish a TanStack performance difference or a scaling limit. The [corrected five- and 25-reader campaign](../../results/diagnostics/extended-fanout-smoke/VERIFICATION.json) passes both TanStack cases at both scales, with complete native data, commit receipts and reader protocol validation. All ten attempts across the four new adapters and Syncular pass. The separate [offline recovery regression](../../results/diagnostics/tanstack-fanout-recovery-regression/VERIFICATION.json) passes at 10/100/500/1,000 writes, retaining complete native queued payloads and unsettled commits during outage, followed by exact persisted and independent-reader convergence.
