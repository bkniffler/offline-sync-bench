# Electric acceptance now ends at the mutation response

The Electric collaboration adapter records server acceptance immediately after validating the `/admin/write` response. Its separate Shape reader establishes visibility. Every warmup and measured write retains the requested task/title, raw response and returned version; the 50 measured samples bind to their receipt titles.

## Confirmed harness cause

The old adapter called `writeTask()` and then recorded acceptance. That helper waited for the mutation response and made a second `/admin/tasks/:id` request before returning. Acceptance therefore included an administrative reread after the response had already confirmed the mutation.

The implementation is preserved at source `7429a67b52c8dbc2f70204469d4a83edec4b40e6a4cf7e766231c1935385b1c3` in the [latency campaign source snapshot](../../results/diagnostics/network-collaboration-latency/SOURCE.json). The call is in `src/adapters/electric.ts`; the shared helpers are in `src/stack-manager.ts`. The backend in `services/bench-admin/src/index.ts` returns the updated task identity, title, completion and incremented version after its SQL UPDATE completes.

The old [latency](../../results/diagnostics/network-collaboration-latency/VERIFICATION.json) and [loss](../../results/diagnostics/network-collaboration-loss/VERIFICATION.json) campaigns preserve route and data evidence, but their Electric acceptance values cannot enter a revised performance comparison. The extra request's numerical contribution has not been isolated by a controlled timing experiment. Stored samples receive no retrospective correction.

## Correction and evidence

The dedicated [write helper](../../src/adapters/electric-write.ts) issues one POST, refuses redirects and validates the response before returning. The adapter records acceptance at that return, then stores the receipt. The [contract](../../src/contracts/electric-collaboration.ts) requires all 55 receipts, exact task and completion state, versions 2 through 56, unique operation titles and the declared mutation route. It rejects the old acknowledgment implementation.

The [development campaign](../../results/diagnostics/electric-ack-development/VERIFICATION.json) preserves an initial validation failure. PostgreSQL returned `server_version` as the decimal string `"2"`; the first check accepted only a number. Validation now accepts a safe integer or its canonical decimal string while retaining the original response. Tests reject fractional, padded, exponential, empty and unsafe integer representations.

The [local](../../results/diagnostics/electric-ack-local/VERIFICATION.json), [50 ms each-way](../../results/diagnostics/electric-ack-latency/VERIFICATION.json) and [50 ms plus 1% loss](../../results/diagnostics/electric-ack-loss/VERIFICATION.json) regressions pass Electric and Syncular at the same source `ec55a3133054ab47bcf2dbce7b7354fa22cdd476fb392fed8d2378f0e2b3ee61`. Each Electric attempt retains 55 valid receipts and 50 measured operation bindings. Across the three campaigns, 61 deliberate receipt, implementation and network-evidence corruptions are rejected. Both archived v2 Electric results are rejected by the current acceptance validator. Each corrected campaign carries a validated explanation bound to its exact Electric result; changing that result invalidates the annotation. The full suite passes 158 tests with 973 assertions, plus TypeScript and whitespace checks.

These checks establish the corrected boundary and application correctness. One independent attempt per profile cannot estimate a speedup or variability. A later publication must use fresh trials under the repaired contract.
