# Restoration time changes the recovery question

The [eight-adapter live-replay campaign](../../results/diagnostics/recovery-restoration-smoke/VERIFICATION.json) passes a common restoration boundary at source `ad48a200cd10a6a953ad5c7d17ea49aeae1bcc934aafee428fb926886e11585c`. Each attempt blocks the writer route, queues ten writes, verifies all 2,000 local records and the unchanged independent reader, then restores the route 20 seconds after blocking. Native and benchmark-owned queue guarantees remain explicit in the result profiles.

Previously, the controller restored connectivity after an adapter-specific probe and its subsequent checks finished. Zero's 11-second probe placed restoration between roughly five-second native retry events. The [earlier Zero investigation](./zero-recovery.md) accounts for the resulting near-four-second wait in its ten-write observation. That wait described the chosen restoration phase as well as the tested implementation.

The repaired policy declares an absolute deadline before blocking. Offline checks must finish first; the controller rejects a missed readiness deadline or more than 250 ms restoration lateness. Native probe behavior stays unchanged and documented. A failed probe still has to exercise the blocked route. Complete interval counters and per-endpoint TCP events must agree, and the declaration is part of the comparison profile.

## Recorded boundary, one attempt per adapter

All times below use the controller's monotonic clock. The first two columns are elapsed milliseconds since the blocking anchor. The last is the wait from the restoration marker until the first forwarded TCP connection. It is not an SDK connection-state event or a measure of server processing.

| Adapter | Probe finished, ms | Restoration, ms | First TCP connection after restoration, ms |
| --- | ---: | ---: | ---: |
| powersync | 13.9 | 20002.5 | 2.2 |
| jazz-v2 | 1039.4 | 20001.7 | 1.0 |
| zero | 11010.3 | 20002.6 | 23.1 |
| electric-tanstack | 15.2 | 20002.3 | 3123.7 |
| electric | 2.8 | 20002.6 | 0.8 |
| syncular | 9.1 | 20002.2 | 1.2 |
| syncular-rust | 32.0 | 20002.2 | 0.8 |
| turso | 9.7 | 20001.7 | 1.5 |

This establishes the common boundary, not a product ranking. In particular, the short Zero wait at this restoration time does not establish improved queue processing. The driver still uses native retry behavior. PowerSync and Jazz retain explicit reconnect behavior in their documented probe/replay paths, while Zero and TanStack keep native retries running. Those implementation differences remain visible.

Sixty-four deliberate evidence corruptions are rejected, including early/late restoration, late readiness, missing endpoint timelines and changed counters. The archive retains full source, dependency, executable, configuration, storage and result bindings plus a validated explanation tied to all eight results. Resources cover the complete outage and recovery, starting before blocking; fixture/client initialization is excluded.

## Extended checks and restoration-phase experiment

The [extended regression](../../results/diagnostics/recovery-restoration-extended/VERIFICATION.json) has finished at the same source: 13 attempts complete all 27 declared scale/restart checks, while Zero and TanStack Node correctly report their memory queues as unsupported for process restart. All 104 timing and counter corruptions are rejected. Turso queue scaling fails during initial replica setup, before blocking, and therefore contributes no recovery timing. Its native client reports an unexpectedly closed socket after about 73 MB received; a contemporaneous server log reports a broken pipe. Both service identities and start times remain unchanged. The archive preserves the failed result, scoped logs and an unexplained annotation with a proposed direct/relay transfer experiment. The later Turso restart success does not establish the cause or repair the earlier failure. The [predeclared Zero phase experiment](../../results/diagnostics/zero-restoration-phase/VERIFICATION.json) passes all nine attempts at 12, 14 and 16 seconds. Its [result-bound analysis and chart](./zero-recovery.md) account for the wait to the first forwarded TCP connection separately from later independent-reader completion. Restoration phase changes the median visibility duration from about 1.1 to 4.1 seconds in this configuration. Three attempts per duration do not provide publication uncertainty estimates. A fixed 20-second case must not be presented as general recovery performance across arbitrary restoration times.
