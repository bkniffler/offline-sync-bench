# Zero removes revoked rows from its native cache

A row disappearing from a filtered view would not establish removal from the client cache. The Zero access case checks both: the active materialized query and the raw task rows returned by the pinned SDK's local inspector. It retains complete records from both surfaces for independent validation.

The query uses the server-verified JWT subject in a native membership-existence relation. This follows Zero's [authenticated query pattern](https://zero.rocicorp.dev/docs/auth). An access-only grant permits that query and rejects the unrestricted benchmark queries and mutation endpoint. Existing global workload grants retain their original query scope.

The [six-attempt campaign](../../results/diagnostics/zero-access-smoke/VERIFICATION.json) establishes the following for the tested memory client:

| Check | Raw cache and visible output |
| --- | --- |
| Before revocation | All 1,000 canonical tasks |
| After online revocation | Exactly the retained project's 500 tasks |
| Revoked while offline | All 1,000 original tasks remain available |
| After reconnect | Exactly the retained project's 500 tasks |
| Fresh affected actor | Only the retained project's 500 tasks |
| Fresh unaffected actor | All 1,000 tasks |

The affected native client ID and storage key stay unchanged. The application does not delete task rows, dispose the query or replace the cache to cause removal. Both token scope and data scope are checked: a [live endpoint probe](../../results/diagnostics/zero-access-smoke/CONFIGURATION-PROBE.json) rejects global-query and mutation bypasses, missing or forged credentials, and an attempt to supply another actor in query arguments. The database remains unchanged throughout that probe.

This confirms native read-scope removal in the active memory client. It does not establish process durability or erasure of copies outside that cache. Identity issuance uses a fixed benchmark signing key, so this is not a production login assessment. Reconnect timings include the SDK's transport schedule, raw-cache observation and IPC; the smoke alone cannot isolate those costs or support a performance ranking.

Global startup and collaboration pass in the same campaign. Both [100,000-task screen regressions](../../results/diagnostics/zero-access-screen-regression/VERIFICATION.json) also pass after the shared schema and authenticated endpoint change. The [structured finding](../../results/diagnostics/zero-access-smoke/CAMPAIGN.json) binds the explanation to the exact native results and their source/configuration identities.
