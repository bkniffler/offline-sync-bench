# Existing objects bypassed the upload retry fault

The first deterministic-payload campaign passed Rust and then failed JS with
“Injected upload outage did not preserve the pending blob.” Both attempts and
their exact source are preserved in the
[development campaign](../../results/diagnostics/attachment-interruption-development/initial-campaign/CAMPAIGN.json).

The application reset truncates Postgres tables, including blob references, but
leaves MinIO objects. Both adapters now use the same payload, so Rust had already
stored the object JS intended to upload. A subsequent
[upload-grant probe](../../results/diagnostics/attachment-interruption-development/existing-object-probe.json)
returned HTTP 200 with `present: true` for that exact content address. In the
installed 0.16.1 server, `handleBlobUploadGrant` returns this marker when the
object exists. The JS client accepts the marker without issuing a PUT. A fault
that rejects PUTs therefore cannot exercise queue retention in that state.

Setup now runs after the application reset, removes only the two declared
benchmark objects, and records existence before and after deletion. Both were
present before preparation and absent afterward in each attempt of the
[corrected campaign](../../results/diagnostics/attachment-interruption-smoke/CAMPAIGN.json).
Both adapters then passed the upload queue retry and the separate interrupted
download. The original failure remains visible in the validation index.

This correction establishes the need to control object presence when measuring
an upload. It does not quantify a performance difference between products.
Deduplication can be useful application behavior; measuring it would require a
separate declared case with the object intentionally present.
