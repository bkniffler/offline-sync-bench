# Jazz screen resources: separate the seeder from the reader

The original Jazz local-query runner seeded and read the fixture in one process. Disconnecting the seed client did not prove that its native allocations had been released. Resource samples could therefore include fixture-construction memory alongside the measured reader.

The corrected runner seeds in a separate process, confirms edge durability and validates all 100,000 canonical tasks. The controller waits for that process to exit successfully before launching a reader with a new product store. The reader independently materializes and validates the same dataset before screen measurement begins.

The [isolation smoke](../../results/diagnostics/jazz-screen-isolation-smoke/CAMPAIGN.json) passed the complete dataset and list, search and aggregate output checks. All 3,909 external samples included reader PID 64813 and excluded seeder PID 64344 and controller PID 64343. Seeder exit was observed before reader creation. These receipts establish the process scope of this run.

The [verification record](../../results/diagnostics/jazz-screen-isolation-smoke/VERIFICATION.json) checks the archived source, raw result, comparison profile and result-bound annotation. Publication rejects this single-trial smoke. The [original result](../../results/diagnostics/jazz-screen-isolation-development/original-local-query.json) remains preserved and now fails validation because it lacks separate seeder/reader proof.

This establishes that seed allocations cannot remain in the reader through a shared process. It does not establish lower memory use or faster queries: the old and new runs used different source versions and were not a controlled performance experiment. Server state and OS caches remain shared. RSS includes the reader's native storage and query work; the aggregate implementation materializes local rows and groups them in JavaScript.
