# RFC 0001: Meaningful comparisons and explainable results

Status: Implemented; corrected publication verified 2026-09-09  
Date: 2026-09-06

Presentation update, 2026-09-09: the user requested a shorter explanation, essential result tables, nearby caveats and links to details. This supersedes the main-page length, opening and embedded chart/coverage layout below; the measurement and evidence requirements remain.

## Proposal

I propose three changes:

- **Compare equivalent application outcomes.** Keep the current products, consolidate overlapping scenarios, and separate profiles with different guarantees. Add offline restart, conflicting edits, and real reconnect backlogs. Remove misleading rankings and move bundle footprint into an appendix.
- **Explain differences with auditable evidence.** Attach observations, traces and controlled experiments to specific results. Distinguish confirmed causes, supported hypotheses and unexplained behavior. State what each finding means for someone building an offline app.
- **Make the report selective and the data complete.** Publish a compact coverage overview and three to five findings in `RESULTS.md`. Keep the full measurement matrix, repeated trials and resource series in linked artifacts, with detailed explanations in investigations.

Dataset sizes, queue sizes, and resource measurements should support those findings without each becoming a separate report section. The sections below specify the comparison rules, workload changes, evidence requirements and publication gate.

Implementation is tracked in the [RFC implementation record](../implementation/rfc-0001.md). Historical measurements remain preserved; each comparison requires fresh validation under the new contracts.

## Why change it

The original harness covered useful workflows and published raw results, but adapters could drift while retaining the same scenario and metric names. The pre-RFC implementations and [historical published outcomes](../../results/history/2026-09-05/RESULTS.json) contained examples that affect interpretation:

- Local-query measurements used 10,000 tasks for Syncular JS and Rust, versus 100,000 for the other measured stacks. Query limits and aggregation outputs also differed.
- Deep-query measurements contained 10,000 tasks for Syncular JS and 8,000 for Rust, versus 100,000 elsewhere. The Rust adapter used a fixture sample limited to four projects despite seeding five.
- Write acknowledgment could mean a local commit or a completed server sync round. Offline replay could end at server verification or second-client visibility, and one path included application-service startup.

These are reasons to withhold comparisons until their contracts match. They cannot support explanations that one product is faster.

The report also repeats numbers across scenario, repeat, scale, and resource tables. Readers have to assemble the important conclusions themselves. Product-specific coverage notes and upgrade investigations add useful detail, but compete with the main report as entry points.

## 1. Compare application outcomes within explicit profiles

A comparison is eligible only when the workload, expected output, timing boundaries, and required guarantees match. Adapters may use different supported implementations to deliver that outcome. Each result must identify how it did the work.

Record the client runtime, local storage, persistence guarantees, query execution model, subscription scope, server configuration, and network conditions. Keep browser and native/server-runtime clients in separate comparison groups. Keep experimental releases visible in their own group.

For local screens, native SQL, reactive queries, and application-side processing can all be useful implementations. Label them explicitly. A timing for JavaScript processing over materialized arrays describes that application path; it cannot establish the performance of a product's native query engine.

Separate three concepts currently compressed into capability labels:

| Concept | Examples |
| --- | --- |
| Capability coverage | Implemented here, not implemented here, unsupported by the tested product/configuration |
| Implementation | Product-native path, supported combination, benchmark-added behavior |
| Attempt outcome | Passed, failed, timed out, invalid measurement |

Missing coverage must not imply that a product lacks a feature. Missing telemetry must remain unavailable rather than becoming zero. A failed correctness check must remain visible and exclude that trial from latency comparisons.

We should keep the current product roster during this change. Broader product admission can be discussed separately once the comparison contracts are reliable.

For the adapters currently in this repository, that means:

| Comparison | Decision and interpretation |
| --- | --- |
| Syncular JS and Rust | Keep as separate client implementations against the same server. Differences include the runtime, storage bindings and harness bridge; a result alone cannot isolate the effect of the language. |
| Electric and Electric + TanStack DB | Keep both. They answer what the tested client composition provides and costs. Compare equivalent application outcomes, and identify the query, persistence and write-queue behavior added by each configuration. |
| PowerSync, Turso and Zero alongside Syncular and Electric | Keep all three. Admit each tested configuration to the suites whose output and guarantees it satisfies. Full-database replication and scoped subscriptions can answer the same startup question when they deliver the required offline data; record subscription scope and transferred bytes so the reader can assess the cost. A partially loaded screen cannot stand in for a complete offline dataset. |
| Stable stacks and experimental Jazz v2 | Retain Jazz coverage in an experimental group. Do not mix its results into stable rankings. |
| SQL, reactive queries and application aggregation | Compare the same correct screen output with execution strategy labeled. Use a separate diagnostic experiment to investigate query-engine efficiency. |
| Native offline queues and the benchmark-owned Electric outbox | Retain the custom outbox as a documented reference implementation. Exclude it from claims about product-provided offline durability. |

Do not introduce an overall product score. Startup, query latency, durability and access behavior answer different application needs, and a weighted total would hide those tradeoffs. Remove invalid comparisons from published rankings while preserving their raw measurements and the reason for exclusion.

## 2. Consolidate the workload suites

| Suite | Question and measurements | Change from today |
| --- | --- | --- |
| Startup | Time to the first correct usable screen, complete offline dataset, and reopening an existing replica | Extend bootstrap with separate milestones and explicit cold/warm server cases |
| Collaboration | Local commit, server acceptance, and visibility on another client | Keep online propagation; give each milestone its own metric |
| Offline recovery | Survival of queued writes, replay, and convergence on a second client | Merge offline replay and large queue; add restart and conflict cases |
| Local screens | Filtered task list, project detail, and organization dashboard over equivalent local data | Merge local and deep queries under shared fixture and output contracts |
| Client fanout and recovery | Delivery to connected clients, then recovery of disconnected clients with a backlog | Separate ordinary update fanout from an actual reconnect storm |
| Access revocation | Removal of revoked data, preservation of authorized data, and behavior after reconnect | Keep as a correctness-led capability suite |
| Attachments | Upload, metadata visibility, fresh-reader download, and interruption recovery | Keep as an optional extension |

Dataset, queue, and client counts become parameters within these suites. Extended scales remain available without dominating the default campaign.

Consolidation removes duplicate report sections, not useful test coverage. Keep ordinary connected fanout as a baseline for reconnect recovery, and keep simple screens as a baseline for relationship-heavy screens. Add a new case when it answers a distinct application question or tests a plausible explanation. Another dataset size or product configuration should normally extend an existing case.

### Add durability and conflict behavior first

The first new offline case should queue writes, terminate the client process, reopen its persistent store while still offline, and verify the pending work before restoring connectivity. Measure successful delivery and convergence after recovery. Memory-only profiles are ineligible for this persistence case.

The next case should exercise concurrent edits, including update/update and update/delete. Record the product's declared conflict behavior and verify convergence against it. Different conflict policies can be valid, but their resulting user-visible behavior must remain explicit. A latency comparison requires compatible outcome guarantees.

For ordinary replay, restore the client's network against a healthy running service. Service restart and infrastructure recovery belong in separate cases. The recovery timer ends only when the declared completion conditions hold, including second-client visibility where required.

Access revocation must describe what the test can establish. An offline client cannot receive a revocation until it reconnects, and removal from its local store does not establish that previously copied data has been erased.

### Move footprint out of the headline comparison

Keep bundle-size measurements as a deployment appendix. Label existing entrypoint measurements narrowly. A future application-footprint case should include the assets required by a working client, including storage dependencies, workers, and WASM where applicable.

Retain detailed resource and product-specific scale studies as supporting artifacts. They become main-report findings when they explain a practical tradeoff.

## 3. Make comparable measurements a harness responsibility

The harness should own fixture parameters, expected results, warmup, repetitions, timing definitions, fault injection, and validation. Adapters should implement product operations and expose relevant milestones.

Shared contracts must check complete local materialization and actual query outputs. Matching row counts alone cannot establish that the right rows, ordering, fields, or aggregate values are present. Validate results outside the timed operation where possible, and retain enough evidence to audit the check.

Run independent trials in fresh processes with seeded randomized execution order. Use shared warmup rules and record individual samples. Publish the number of independent trials separately from the number of operations within a trial. Estimate uncertainty across trials; do not present a 15-observation maximum as an established p99.

Measure resource usage externally so synchronous client work cannot block sampling. Distinguish baseline, peak, and retained memory, and use consistent setup and measurement windows. Preserve streaming in transport instrumentation and check its overhead against uninstrumented trials. Distinguish application payload bytes from wire traffic and disclose incomplete transport coverage.

Start with a controlled local network profile. Add a declared higher-latency profile after the contracts pass, followed by loss and interruption experiments. Changing network conditions should create a new result profile.

Every published campaign must identify the source revision and dirty state, dependency and image identity, fixture and workload contract, configuration, runtime, machine, network profile, and measurement method. Reports must refuse to aggregate incompatible profiles. Record failed attempts and their elapsed time; return a failing CLI status for failed required cases.

## 4. Explain results with evidence

Each headline finding should state what happened, why the evidence supports an explanation, and when the difference matters to an application developer. Explanations belong to specific results and configurations so they can be reconsidered when implementations change.

| Evidence status | Requirement |
| --- | --- |
| Confirmed | A controlled experiment or direct accounting establishes the stated cause within the tested scope |
| Supported hypothesis | Traces or measurements support an explanation, but plausible alternatives remain |
| Unexplained | The observation is reproducible, but the cause has not been established |

Architecture descriptions alone do not establish causes. A request-count correlation can justify investigating batching; it does not prove that request overhead accounts for a latency difference.

Collect diagnostics appropriate to each suite:

| Suite | Evidence useful for explaining differences |
| --- | --- |
| Startup | Rows and bytes received, requests, server preparation, local materialization, persistence work |
| Collaboration | Local commit, upload, server acceptance, delivery, local apply, observation delay |
| Offline recovery | Batch sizes, requests, retries, backoff, queue drain, second-client catch-up |
| Local screens | Query plan or execution strategy, rows processed and returned, indexes, caching |
| Client recovery | Connection attempts, backlog, retries, per-client completion distribution, server resources |

Use monotonic clocks for durations within a process. Cross-process spans need explicit clock handling. Phases can overlap and must not be presented as an additive breakdown unless the instrumentation establishes that relationship.

Keep annotations in structured records alongside results, with the affected result IDs, observation, evidence status, explanation, evidence links, practical implication, and next experiment where applicable. Render these into Markdown rather than maintaining duplicate explanations by hand. A changed workload or implementation requires annotation review.

An illustrative annotation, not a claim about a current stack:

> Replay time rises with queue size. The trace records one upload per write, which supports request overhead as a possible cause. We have not isolated server processing from network overhead. Next, vary network latency while holding the queue and server constant, then compare an officially supported batching configuration if available.

Diagnostic experiments may change one setting to test a cause. Keep their results separate from the comparison campaign until the changed configuration qualifies as a declared profile.

Prioritize investigations by the importance of the result: a reproducible failure, a large gap, an unexpected scaling curve, or a difference that would change an application decision. First check that the harness measures equivalent work. Then choose an experiment that distinguishes competing explanations, such as varying latency to test request overhead or comparing fresh and previously populated server storage to test retained state. Record preparation history; resetting logical rows alone does not establish equivalent physical storage. Keep profiling overhead out of headline timings unless it has been measured and disclosed.

## 5. Publish a shorter report

Use four main document locations:

| Location | Contents |
| --- | --- |
| `README.md` | What the benchmark answers, quickstart, links to results and methodology |
| `RESULTS.md` | Campaign scope, compact coverage/outcomes, selected charts, three to five substantive findings |
| `docs/methodology.md` | Shared contracts, comparison profiles, measurement rules, limitations |
| `docs/investigations/` | Detailed causal investigations linked from individual findings |

Retain scenario specifications as concise contract details linked from methodology. Archive completed upgrade comparisons and historical notes with their campaigns. Preserve original raw artifacts and provenance.

For each selected finding, show the application question, one chart or compact table, the observation, the evidence-backed explanation, and the practical implication. A chart should include workload size, units, profile, sample count, and uncertainty. A scale chart can replace separate headline, repeat, and scale tables. Explain failures and timeouts alongside successful observations.

The main report should target roughly 1,000 to 1,500 words excluding chart labels. The full matrix, samples, resource series, and manifests remain available as structured artifacts. The compact coverage overview must still expose missing and failed cases so editorial selection cannot hide them.

Choose findings because they reveal a tradeoff, failure, scaling limit, or unexpected result. Include unexplained findings when the observation is useful. Do not require a winner or give any product a standing place in the highlights.

Open the report with the most useful finding, followed by a short statement of what was tested and the coverage overview. Give findings descriptive titles that state the observed behavior. For example, “Local writes stay responsive while the recovery backlog grows” would be more useful than “Offline replay results,” provided the measurements support it. Follow each finding with the relevant comparison, explanation, and limitation so readers can assess the claim without opening several documents.

Remove tables that repeat the same measurements in another arrangement, repeated setup instructions, and boilerplate conclusions generated for every scenario. Keep setup and metric definitions in methodology, and put complete per-trial tables in the companion artifact. Do not generate explanatory prose from rank alone: “A is fastest” adds little when the table already says that. Use the space to explain the size of the difference, whether it is consistent across trials, and the application behavior it affects.

## 6. Rollout and acceptance

1. **Correct the existing comparisons.** Audit current contracts, add shared fixture/output checks, and mark affected historical comparisons as non-comparable while preserving their raw results. Separate acknowledgment and recovery milestones. Add contract tests for the known dataset, project-subscription, and query-output mismatches.
2. **Establish a reproducible campaign runner.** Add profile validation, independent trials, shared warmup, external sampling, and complete failure reporting. Require an explicit campaign manifest for publication. Test that a failed latest attempt cannot be replaced by an older success, and that incompatible runs cannot enter the same aggregate.
3. **Publish the first explainable report.** Rerun eligible existing cases, produce a compact coverage summary, and attach structured evidence to selected findings. Audit metering overhead. Consolidate repeated Markdown and move detailed investigations into their proposed location.
4. **Expand behavior coverage.** Add persistent offline restart, conflicting edits, actual reconnect backlogs, and then additional network and browser profiles. Mark cases not yet implemented explicitly.

The first revised report is ready when every comparison passes its workload and profile checks, failures remain visible, samples and provenance are accessible, and each explanatory claim links to evidence with an explicit confidence status. Existing checks that validate only metric presence are insufficient for this gate.

Review the generated report against these acceptance checks:

- Each comparison names the application outcome and groups only compatible workloads and guarantees. Excluded attempts retain an explicit reason.
- Each selected finding binds to the exact results it discusses, includes the relevant failed attempts, and labels its explanation as confirmed, a supported hypothesis, or unexplained. A hypothesis names the next experiment.
- The main page contains three to five findings and one compact coverage overview. Repeated trial tables, exhaustive metrics and resource series appear in the linked companion.
- A reader can follow a finding to its investigation, raw samples and campaign manifest. Regenerating the report preserves the reviewed annotations and rejects stale result bindings.

## Tradeoffs and decisions still needed

Fresh processes, repeated trials, browser runs, and diagnostic traces increase campaign cost. Keep a small correctness smoke suite for development and a separate publication campaign. Determine publication repetition counts from a pilot's observed variability and record the stopping rule before collecting the final campaign.

Strict profiles will produce fewer eligible comparisons initially. Missing coverage should remain visible while adapters catch up. Shared contracts must allow different product implementations without weakening the expected application outcome.

Before the first revised campaign, choose the initial browser/runtime targets, canonical fixture and query outputs, network settings, and practical uncertainty thresholds. The proposed defaults are to repair the current native/runtime coverage first, preserve the documented 100,000-task query workload as a common case, and add the browser lane once the shared contracts work.
