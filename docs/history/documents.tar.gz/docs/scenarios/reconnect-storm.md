# Reconnect with backlog

`client-fanout-recovery-v1` measures recovery after an actual client outage. It uses the same writer, reader processes, 2,000-task fixture and resource scopes as [connected fanout](./connected-fanout.md).

1. Bootstrap each replica and deliver a readiness marker through the live connection.
2. Block all reader routes, dropping established connections. Pause explicit transports where the adapter exposes that lifecycle; Zero and Electric-based streams retain native retry behavior behind the gate. Route probes must be refused.
3. Commit 100 distinct updates while readers remain disconnected. A separate healthy witness verifies the complete server dataset; every offline reader must still match its pre-outage snapshot.
4. Start the clock, restore all routes together, and run native catch-up sync followed by subscription reconnection.
5. Record each reader's completion independently and verify every final row outside timing.

The service stays running during the outage and measured recovery. The witness closes before measurement. The writer remains present but idle during reader catch-up. The timer excludes fixture setup, readiness checks, outage construction and backlog creation.

Default scales use 5 and 25 readers; campaign `parameters.clientCounts` supports declared extended scales. Metrics include each reader's completion and the time until all readers converge. Server counters retain their bracketing collection windows, which are not an additive breakdown of client latency.

A matching last update cannot establish complete replay. Missing readers, leaked traffic, missing backlog evidence, incorrect unchanged rows or a changed service process invalidate the case. Failed scales remain in the artifact, and subsequent scales still run.

The initial development attempt only reopened the subscription. Syncular readers remained stale despite a healthy witness holding all 100 updates. The corrected resume path explicitly requests native catch-up before resuming live delivery. Both the failure and subsequent checks remain in the [harness investigation](../investigations/fanout-harness-corrections.md).

All eight adapters now have shared implementations. Electric, TanStack, Zero and Jazz also retain native delivery, cache identity and auxiliary-data receipts. Their canonical five/25-reader migration checks pass in the [archive](../../results/diagnostics/extended-fanout-smoke/VERIFICATION.json). The historical one-update catch-up sweep is preserved in archived results.
