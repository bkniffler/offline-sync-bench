# Access revocation

`access-revocation-v1` and `access-refresh-v1` verify that revoking one project removes exactly its data while preserving all still-authorized data. The fixture contains two projects with 500 tasks each and two actors authorized for both projects.

Each mode starts from a fresh client and verified 1,000-row snapshot. The server deletes one membership for the affected actor. The client invokes its declared strategy and must retain exactly the other project's 500 canonical rows.

| Profile | Implementation | Verified storage outcome |
| --- | --- | --- |
| Native purge | Syncular JS/Rust sync the original persistent replica | The product removes revoked rows from the same store |
| Native continuous purge | PowerSync applies membership-scoped buckets in the existing SQLite replica | Exact retained rows and unchanged file device/inode; both token and sync routes are blocked offline |
| Native continuous purge, memory | Zero applies a membership-existence query in the existing native client | Full raw cached task rows and active view rows both match the authorized dataset; no cache replacement |
| Application refresh, memory | Electric creates a replacement SDK Shape snapshot through the actor-scoped app proxy | The old active snapshot is disposed and the replacement contains exactly the authorized rows |
| Application refresh, SQLite | Electric + TanStack disposes its old collection/cache and creates a replacement | Old SQLite cache files are removed; the new collection and persisted rows both match the authorized dataset |

The refresh strategy is benchmark application behavior, not native permission purge. The application deliberately resets its cache after the declared trigger; server membership scoping controls the replacement data. Reports keep these five profiles in separate tables. PowerSync and Zero use their declared continuous native delivery and reconnect strategies; Syncular uses explicit native sync. Zero also retains its memory-only persistence limit.

| Mode | Timer starts | Timer ends |
| --- | --- | --- |
| Online | Before the admin revoke request | The client returns its complete retained snapshot |
| Offline reconnect | When all affected-client routes are restored | The client returns its complete retained snapshot |

Online timing includes the revoke acknowledgment. For offline reconnect, the server revokes membership while every affected-client route is blocked; a local snapshot must still match all original rows before restoration. The revoke request is recorded separately. The declared strategy determines the remaining work: explicit native sync, continuous PowerSync/Zero delivery and reconnect, or application refresh. Timings include observation and IPC; refresh also includes disposal and required persistence. They are not isolated server notification timings.

After each operation, fresh clients request the original scope or actor-scoped endpoint. A fresh client for the revoked actor must receive only the retained project. A fresh client for the unaffected actor must still receive both projects, proving that revocation did not remove shared server data. Exact rows, fields and digests are checked outside timing; counts alone cannot qualify a result.

External resources cover the affected client and native descendants, excluding the controller, sampler and later fresh-client checks. The sync service remains healthy with the same process identity across revocation and validation. Each result preserves both modes, acknowledgment details, client identities, outage counters and raw samples. Failed modes remain visible.

Syncular JS/Rust, PowerSync, Zero and Electric/Electric + TanStack pass the profiles above. Jazz executes a separate native profile with failed purge outcomes. The current Turso whole-database profile has no equivalent row-revocation path.

The [canonical Jazz investigation](../investigations/jazz-access-revocation.md) records both 60-second purge timeouts with independent clients and the shared network gate. Online queries drop revoked tasks while an unscoped local query still finds the original records. After route restoration, the visible result also stays stale. Both fresh actors receive the correct data. The adapter preserves raw, visible and subscription records, native edge receipts and unchanged server data after a timeout. Its resource sampler targets the affected process directly, excluding the separate administrative client. No successful latency is reported for failed cases.

PowerSync access clients receive a signed access-only grant. Its source membership table determines project buckets; ordinary workload clients use a separate global grant. The [verified investigation](../investigations/powersync-access-revocation.md) records the native checks. The benchmark supplies actor identities; it does not test login security or write authorization.

Zero access clients use a server-verified JWT subject and a native membership relationship filter. The [native cache investigation](../investigations/zero-access-revocation.md) verifies complete raw and visible rows in the same client, including the offline snapshot and both fresh actors. Its access grant cannot invoke global benchmark queries or mutations.

An offline client cannot receive revocation until reconnect. Removal from the tested product store does not establish erasure of previously copied data.
