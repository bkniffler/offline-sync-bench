# Collaboration

The `collaboration-v2` contract starts with 200 validated tasks visible on a second client. Run five warmups and 50 measured title updates through the tested application write path.

Each sample records local commit when exposed, client-observed server acceptance, and independent second-client visibility. A combined sync response can establish server acceptance after other response work; the adapter records that boundary. Optimistic state alone is not labelled a durable local commit. Missing local receipts remain unavailable.

The reader observation runs independently of the writer receipt. Shared polling uses a 1ms scheduling interval; Rust uses its native query loop and transport processing. Transport round trips, IPC and scheduling can add observation delay. Each adapter records its reader behavior, including explicit pull where required. No p99 is reported from this sample count.

Raw samples, validation evidence, measurement boundaries and external resource samples accompany the result. Publication uses independent trials under the [campaign methodology](../methodology.md).
