# Conflicting edits

The `conflicting-edits-v1` contract tests one stale update against a competing update or deletion across all eight adapters. Queue ownership and application policies remain explicit. Jazz update/delete times out in the [native smoke](../../results/diagnostics/jazz-conflicts-smoke/VERIFICATION.json), with its cause under investigation.

Three clients start with the same 2,000-task fixture. A queues its edit behind a TCP gate. B updates or deletes the same task. A third client must observe B's operation before A reconnects, proving that B's local optimistic view is not the only evidence of acceptance. A must still have its original queued edit at that point.

The expected policy is declared before the run:

| Tested path | Update/update | Update/delete |
| --- | --- | --- |
| Syncular JS and Rust, explicit `baseVersion` | Reject A with `sync.version_conflict`; retain B's title | Reject A with `sync.row_missing`; retain deletion |
| PowerSync with this repository's SQL PATCH backend | Apply A's later patch; retain A's title | PATCH affects no existing row; retain deletion |
| Electric and Electric + TanStack with the shared SQL conflict endpoint | Apply A's later update; retain A's title at application version 3 | Persist an explicit zero-row update receipt; retain deletion |
| Turso native SQL update replay | Replay A's changed columns; retain A's title | UPDATE affects no existing row; retain deletion |
| Zero with the existing title-only application mutator | Apply A's later title patch; retain A's title | Mutator ignores the missing row; retain deletion with a successful native receipt |
| Jazz native timestamp-ordered update and soft delete | Retain B's later-written title; both edge receipts must settle | Test the application requirement to retain deletion; exact native race policy remains unverified |

These describe configured write paths. PowerSync and both Electric compositions use application SQL policies. Syncular is explicitly using a version precondition; its unconditional upsert path has different semantics. Turso's expectation is tied to SQL UPDATE replay, not insert/upsert behavior.

Zero uses the existing shared `tasks.update` mutator, which changes only the title and returns when the row is absent. The peer deletion uses `tasks.remove` and the native keyed delete operation. The fixture's `server_version` stays at 1 on this path; it is an application field, not Zero's internal version or a precondition. Both cases pass the [native migration smoke](../../results/diagnostics/zero-conflicts-smoke/VERIFICATION.json). This tests the configured application behavior, not a product-wide conflict policy.

After A receives its native disposition, all three clients must observe the expected result and have no pending application writes. Every task is validated, including the 1,999 untouched tasks. Syncular's native error code must identify the contested task. Missing native rejection/conflict counters for the SQL paths remain null.

Zero retains fresh memory-cache identities and actual native local/server receipts for all three clients. Its writer has a successful local receipt and pending server receipt during isolation, then a successful server receipt after restoration. The independent observer proves the peer's operation before restoration, and final full snapshots verify convergence. The SDK-wide queue count stays unavailable; no process durability is claimed. A successful missing-row patch receipt confirms the configured no-op, not an applied row update.

Jazz uses three fresh native Node/SQLite clients after a separate seeder confirms edge durability and exits. It attaches an edge waiter immediately to each native write handle, before awaiting local durability. Full edge snapshots and stable native batch/row identities supplement the common local-data checks. The scoped pending count describes those issued edge waiters; the aggregate native queue remains unavailable. [Controlled diagnostics](../investigations/jazz-conflicting-edits.md) distinguish successful update/update convergence from an unexplained update/delete disagreement. The failure path retains all three clients' actual records and receipts.

Electric and TanStack retain [exact application SQL dispositions](../investigations/electric-conflicts.md), including an accepted missing-row no-op. The receipt must identify the original queued write. Native Shape visibility acknowledges changed rows; a no-op still requires complete auxiliary/active data and independent convergence. Electric's outbox is benchmark-owned persistent SQLite. TanStack's native executor uses a Node memory queue, so this case makes no queue-restart claim.

`writer_settled_ms` runs from A's network restoration to its sync completion. `all_clients_converged_ms` also includes native disposition inspection and all three client observations. Both use the controller's monotonic clock and include IPC receipt. External resources cover resolution; setup and offline queue construction are excluded. Full dataset validation follows outside the timer.

Conflict policies form separate comparison profiles. The report presents behavior and validation outcomes rather than combining them into one latency ranking. The single deliberately ordered race does not establish behavior for every interleaving or field type.

The test checks implementation paths against the pinned Syncular server's version/absence checks, the [application PATCH handler](../../services/powersync-bench-app/src/index.ts), and Turso 0.7.2's [primary-key UPDATE generator](https://github.com/tursodatabase/turso/blob/v0.7.2/sync/engine/src/database_replay_generator.rs#L369). Changing those paths requires reviewing the declared policy and rerunning the contract.
