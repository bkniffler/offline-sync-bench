# Queue scaling

`large-offline-queue` is the 100, 500 and 1,000-write sweep of the [offline recovery contract](./offline-replay.md). Each scale uses 2,000 tasks, fresh clients and stores, a writer-only network outage, and complete second-client validation.

Compare the scale curve from one campaign. Historical results that include service startup or use different queues are not comparable with this contract.
