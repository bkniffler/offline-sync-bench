# Relationship screens

Part of the local-screens suite under [screens-v2](../../src/contracts/screens.ts). Seed one organization, four projects, ten users, four memberships per project and 25,000 tasks per project. Validate all 100,000 tasks and the local project and organization records.

Run five warmups and 25 measured iterations of the organization dashboard and project detail screen, validating exact outputs outside timing. The [methodology](../methodology.md) defines projections, ordering, limits and telemetry. Query execution models remain explicit; array processing over materialized state does not describe a native relationship-query engine.
