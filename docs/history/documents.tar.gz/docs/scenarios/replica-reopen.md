# Persisted replica startup

`persisted-replica-reopen-v1` measures startup from an existing product store. It is separate from initial network bootstrap and from crash recovery with pending writes.

A client materializes the common 2,000-task fixture, verifies it, and closes its product resources. A new process opens the same file with the same client identity while all configured client routes are blocked. The new process receives configuration only. It must serve the shared 50-row task screen and the complete local dataset without receiving network data.

The controller records cumulative milestones from process launch:

| Metric | Completion boundary |
| --- | --- |
| `reopen_process_ms` | Product initialization completes |
| `reopen_first_screen_ms` | The first local task-screen result reaches the controller |
| `reopen_all_rows_ms` | The complete local snapshot reaches the controller |

The task screen uses the same projection, filter, ordering and limit as the local-screen suite, implemented through each adapter’s native query path. All rows, the screen output and the empty native queue are validated outside the timed operations. Independent campaign trials repeat the full preparation and reopen sequence.

External resources cover the new process and its local reads, excluding the controller and sampler. The validator requires that scope and at least two samples. Durations include process launch, SDK/harness loading and IPC. The OS file cache is not cleared after materialization, so these measurements cannot establish cold-disk startup performance. The blocked network is part of the reopen contract, not an assumption inferred from a fast result.

Syncular JS/Rust, PowerSync, Turso, Electric + TanStack and experimental Jazz v2 implement this case. The [extended native smoke](../../results/diagnostics/extended-reopen-smoke/VERIFICATION.json) verifies the new TanStack/Jazz paths and a Syncular controller regression. Electric and Zero use memory-only profiles here and cannot qualify for file-backed process reopening.

TanStack restores its collection through the product SQLite persistence adapter and serves a native live query while the remote source remains offline. The controller validates both persisted and active rows before closing the first process and after reopening the same collection identity. No fixture rows are injected into the new process. This read-only cache test does not establish process durability of the separate Node offline executor, which currently uses in-memory fake IndexedDB.

Jazz uses a separate edge-durable seeder with a unique 2,000-task dataset. That process exits before the first replica reader starts. The reopened NAPI reader finds the same full local dataset without connecting transport, then serves native local queries from its existing SQLite file. Results remain in the experimental group. The backend-secret client and allow-all policy make no end-user authorization claim.
