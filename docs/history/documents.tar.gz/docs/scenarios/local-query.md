# Task screens

Part of the local-screens suite under [screens-v2](../../src/contracts/screens.ts). Seed one organization, one project, two users and 100,000 tasks. Validate the complete local task dataset, then run five warmups and 25 measured iterations of list, prefix search and grouped counts. Validate exact outputs outside timing.

The [methodology](../methodology.md) defines projections, ordering, limits and telemetry. Each adapter records native SQL, native reactive queries, or application-side processing. Raw samples and validation digests remain with the result.

Jazz seeds in a separate process and confirms edge durability before exiting. A new reader process and product store must validate the same complete fixture. Resource validation requires that every sample include the reader and exclude the seeder and controller; see the [seeding investigation](../investigations/jazz-screen-seeding.md).
