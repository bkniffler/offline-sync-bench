# Connected client fanout

`client-fanout-recovery-v1` measures delivery to already-connected readers. Each scale creates one writer and 5 or 25 reader processes, each with a distinct cache and 2,000 tasks. Zero uses memory, the Electric reference application owns its persistent SQLite cache, and the other tested adapters use product persistence. These live-client cases make no process-restart durability claim. A readiness update must reach every reader before timing.

The clock starts before one writer update. Each reader observes its local query through the product's live delivery path; the harness does not issue catch-up sync requests after that write. Every reader's completion uses the parent's monotonic clock, including IPC and local observation delay. The shared query-poll interval is 5ms.

Syncular JS/Rust use WebSocket wakes and native sync, PowerSync uses continuous SDK sync, and Turso uses successive native long-poll pulls with a 1s timeout. Zero observes native materialized queries; Electric applies native Shape updates to the application cache; TanStack retains its native Electric collection stream. Jazz maintains one full edge subscription with deferred local updates. These implementations are explicit in the result diagnostics.

The extended adapters validate complete auxiliary snapshots, such as TanStack's confirmed persisted records and Jazz's local and edge views, before retaining digests. Fresh-cache receipts and native identities establish independent clients. Recorded worker calls distinguish initial setup, live observation and explicit reconnect recovery; an extra controller catch-up or mutation on a reader invalidates the case.

The result retains every reader's completion, p50/p95 across readers and the time until all readers converge. Publication uncertainty comes from independent trials, not from treating these correlated readers as independent runs. Every final 2,000-row snapshot must match, including unchanged tasks.

Client resources cover readers and writer, excluding controller and sampler. Separate raw Docker counters record service usage with request/receipt bounds around the client window. Raw cgroup memory includes page cache and is not client RSS; missing counters remain null. Reader TCP counters include HTTP/WebSocket framing on configured routes, not TCP/IP overhead.

Campaign `parameters.clientCounts` declares other sizes, including extended studies up to 1,000 readers. It creates a distinct workload profile and cannot be silently replaced by ambient environment settings. Standalone runs can use `BENCH_CLIENT_COUNTS=5,25`.

[Reconnect with backlog](./reconnect-storm.md) is a separate case. All eight adapters now have shared implementations; the extended adapters' canonical five/25-reader checks pass in the [migration archive](../../results/diagnostics/extended-fanout-smoke/VERIFICATION.json).
