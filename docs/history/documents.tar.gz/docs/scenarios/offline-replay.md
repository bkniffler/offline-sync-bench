# Offline recovery

The `offline-recovery-v2` contract covers live replay, queue scaling and process recovery. Live replay and scaling now cover all eight adapters. Crash recovery has separate eligibility based on the tested queue and cache guarantees.

| Configuration | Cache / queue storage | Queue ownership | SIGKILL recovery |
| --- | --- | --- | --- |
| Syncular JS/Rust, PowerSync, Turso | Persistent / persistent | Product | Verified |
| Jazz v2, experimental | Persistent / persistent | Product | Verified |
| Zero Node | Memory / memory | Product | Unsupported in this configuration |
| Electric + TanStack Node | Persistent / memory | Product composition | Unsupported with fake-indexeddb |
| Electric reference application | Persistent / persistent | Benchmark application | Verified for the application |

These are distinct comparison profiles. A persisted cache cannot establish that queued writes survive a process exit; a benchmark-owned queue cannot establish a native product capability.


All cases use the same 2,000-task fixture. The writer and reader run in separate processes with separate stores or memory caches. Setup waits for complete canonical initial records even if a native completion signal arrives before the service cache catches up. Each queued operation changes a distinct task's title and application version. The contract checks every task before and after recovery, including untouched records.

| Case | Queued writes | Writer lifecycle |
| --- | --- | --- |
| `offline-replay` | 10 | Stays alive |
| `large-offline-queue` | 100, 500, 1,000 | Fresh clients and stores for each scale |
| `offline-restart` | 1,000 | SIGKILL after local acknowledgment; reopen the same store while still offline |

The writer's TCP gate destroys existing connections and rejects new connections. For PowerSync, it covers both the sync and application upload endpoints. A sync probe must produce a blocked connection without forwarding traffic. For Jazz, the probe reconnects the native transport without leaving a pending receipt waiter. Zero keeps its SDK transport running through an 11-second blocked probe and requires actual refused connections. The independent reader must still sync successfully and retain the unchanged fixture. No service is stopped or restarted.

Restoration now uses `fixed-block-to-restoration-v1`: the controller restores the route 20,000 ms after its monotonic blocking anchor. `parameters.recoveryOutageMs` declares a different diagnostic duration before a campaign starts. Queue construction, the existing native probe, independent-reader validation and any offline reopen must finish before that absolute deadline. Missed readiness or more than 250 ms restoration lateness invalidates the attempt; the harness does not extend the outage to accommodate a slow check. The declaration is part of the result comparison profile.

Per-endpoint TCP event timelines record blocking, refused connections, restoration and forwarded connections on the same controller clock. Validation checks those events against the complete blocked interval and gate counters. TCP connection receipt is distinct from an SDK connection-state event. The existing probes may reconnect or pause native transports as documented above; the fixed restoration clock does not remove that implementation difference. All eight live-replay adapters pass the [new-policy smoke](../investigations/recovery-restoration.md). The extended regression completed with 13 passed attempts, two unsupported memory-queue restart cases and a Turso setup failure before blocking; prior recovery archives retain their earlier restoration boundary.

For process recovery, the new writer receives only its original configuration and file path. Electric uses the benchmark-owned application file; other eligible profiles use product storage. Before reconnecting, its complete local dataset and native pending work must match the acknowledged offline state. Recreating an executor in the same process cannot satisfy this case.

Two independent completion callbacks start from network restoration: `queue_<n>_drain_ms` records the completed application queue check (native queue drain, settled native Zero server receipts, or matching Jazz local and edge-durable records), and `queue_<n>_mirror_visible_ms` records all changed titles on the reader. Durations use the controller's monotonic clock and include worker IPC receipt. Complete row validation follows outside the timer. `queue_<n>_reopen_local_ms` measures opening the persisted store and reading its local state while offline.

External process-tree resources start before blocking and cover the complete outage, queue construction, validation, declared wait, recovery and kill/reopen where applicable. Initial client and fixture setup is excluded. Detailed samples stay under each scale. Writer transfer counters include TCP payload and HTTP headers; they exclude reader traffic and TCP/IP framing.

Native queue counters are not interchangeable. Turso's raw CDC count includes commit markers and internal bookkeeping; its application queue check counts retained task changes after a full push/pull. Raw native counters remain in diagnostics. Missing rejection/conflict counters stay null. [The counter investigation](../investigations/turso-recovery-queue-counter.md) explains the evidence.

Jazz compares complete native local and deferred edge-durable query views. While offline, its local view must contain all edits and its edge view the original fixture; after reconnect, both must match the expected edited fixture. The pending count describes differing application rows, while the aggregate native queue counter stays null. Historical batch-receipt checks can fail after data recovery; [the durability investigation](../investigations/jazz-recovery-durability.md) preserves the failed attempts and supporting probe. The backend-secret configuration is experimental and makes no end-user authorization claim.

Zero observes the native local and server promises for every mutation issued by the trial. The full set must report local success and pending server receipts during outage, then server success after reconnect. This pending count covers the trial's mutations; the aggregate native queue counter remains null. Native storage/client identities and separate writer/reader processes are required. The [reconnect investigation](../investigations/zero-recovery.md) accounts for the observed wait before the next connection attempt and records the completed 12/14/16-second phase experiment and explains why published recovery results must name their outage duration.

TanStack validates every serialized native transaction, its original and modified record, and its eventual commit receipt. During outage, the optimistic collection holds edits while a complete SQLite snapshot still contains confirmed data. Recovery waits for the HTTP transaction ID, native Electric `awaitTxId`, native commit completion and persisted/active equality. Its Node detector stays online and allows native retries against the gated route; the harness does not reconstruct or replay transactions.

The Electric reference application commits optimistic records and outbox entries in one SQLite transaction. It sends sequential idempotent application requests, waits for native Shape visibility, then removes each queue entry. SIGKILL recovery validates every row and the unchanged outbox payloads and idempotency identities before restoring connectivity. The [native migration smoke](../../results/diagnostics/electric-recovery-smoke/VERIFICATION.json) verifies both configurations and preserves their separate guarantees.

These disjoint writes should produce no conflicts. Concurrent update/update and update/delete cases use the separate [conflicting-edits contract](./conflicting-edits.md).
