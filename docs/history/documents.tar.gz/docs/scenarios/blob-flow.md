# Attachments

`attachments-v1` drives the published Syncular JS and Rust blob APIs against
Postgres and MinIO. Both use one project, 50 tasks, two authorized actors and
the same two deterministic 2 MiB payloads. Setup resets application data,
restarts the sync service, removes only the two declared benchmark objects and
verifies their absence. Other objects and OS caches remain intact.

## Workload and milestones

A writer and realtime reader run in distinct processes with new product SQLite
stores. Before staging, both must contain every expected task and no attachment
entries. Payload generation happens before resource and staging measurements.

| Milestone | Timing boundary |
| --- | --- |
| Stage and local commit | Prepared bytes through native blob staging and the referencing metadata mutation |
| Upload | Explicit sync invocation through successful presigned PUT acknowledgment |
| Server acceptance | The same sync invocation through the native response naming the applied metadata commit |
| Reader visibility | The same sync invocation through independent observation of the correct metadata entry |

The parent records monotonic IPC receipt times. The reader polls its native
local query every 5 ms, alongside realtime delivery. Visibility can precede or
follow the writer response. These overlapping milestones cannot be added as
sequential phases. Rust payload conversion through the command bridge is
included in staging and download materialization.

After each successful transfer, both clients must retain all 50 tasks and the
exact expected attachment entries, including task/project IDs, content address,
length, media type and creation time. Upload and metadata queues must be empty,
with no native rejections or conflicts. Exact validation follows the timed
operation; intermediate queue checks are recorded separately.

## Recovery and fresh downloads

The second upload rejects both the presigned and authenticated PUT before any
body reaches the network. Require one retained native upload and metadata
commit, and no new entry on the reader. Restore transport and measure successful
upload, applied commit and reader visibility independently.

Download the first object through another fresh process with an empty product
cache. Require a full authenticated product download, exact length and SHA-256.
A fourth client tests interruption: a streaming relay forwards 65,536 response
body bytes, then closes the connection before the remaining object bytes.
Require native failure and an empty cache. Restore the relay and verify a full
GET, the expected content and one cached blob. The relay preserves the signed
Host, path and query upstream; it records each attempt's status, declared length,
Range header and forwarded bytes. This proves full-object retry, with no
byte-range resume or writer-process durability claim.

## Resources and evidence

External sampling covers both client trees during each staging/sync case,
including intermediate queue checks and the optional failed attempt. Download
sampling covers only its fresh client tree, including the harness content check.
The controller, relay and sampler are excluded. Download completion is captured
before the harness checksum; its resource window is wider than its latency
window. Raw GET counters measure response bodies; total wire traffic and server
storage footprint are not reported.

The [shared-contract smoke](../../results/diagnostics/attachments-smoke/CAMPAIGN.json)
passed both clients, including four upload cases and four fresh download clients.
It includes reviewed annotations explaining independent milestone ordering and
native recovery behavior. Its source, raw observations and resources are
archived. It is a single-trial correctness campaign, not a performance ranking.
The [object-state investigation](../investigations/attachment-object-state.md)
explains why Postgres reset alone did not establish a fresh upload.
