# Selecting findings for a report

Publication requires recorded server-storage preparation and before/after physical observations for each attempt, including each successful startup client. The observations must cover the configured services and data mounts and remain outside the workload window. Unavailable counters stay explicit. These records accompany the campaign’s source archive, installed host dependency inventory, and runtime/service configuration artifact, each verified against its manifest. The generated results link to all three artifacts. Configuration records fingerprint opaque environment values and commands without publishing their plaintext.

Publication generates a short `RESULTS.md`, a complete companion at `results/reports/<campaign-id>/DETAILS.md`, and the raw `RESULTS.json`. The main page shows coverage by suite and three to five selected findings. The companion contains every case table and every reviewed annotation, including those not selected for the main page. Each raw trial JSON and its log are copied into the report's `trials/` directory, with a `TRIALS.json` index and relocated paths in the published manifest. Missing logs fail publication.

Choose findings that explain an application tradeoff, a failure, a scaling limit or an unexpected observation. For the current essential presentation, keep the main page around 300–800 words. Additional explanation belongs in an investigation linked from the finding. Keep failure totals visible and link to the complete coverage overview.

## Author and bind an annotation

Annotations live in the campaign manifest. Each records an observation, explanation, practical implication, evidence status and local evidence links. Bind `sourceHash`, `resultIds` and `resultDigests` to the exact measured source and results using the harness's `hash` function. A changed result expires that review.

A selected annotation also needs an application question and a compact table specification. For example, this is a table specification, not a claim about measured performance:

```json
{
  "question": "How quickly does an already loaded task list respond?",
  "table": {
    "scenarioId": "local-query",
    "metrics": [
      { "key": "list_query_p50_ms", "label": "List p50" },
      { "key": "search_query_p50_ms", "label": "Search p50" }
    ]
  }
}
```

Tables include every configured stack and every trial for their case. Include all those result IDs and digests in the annotation, including failed attempts. The renderer rejects missing bindings and unmeasured metric names. Select at most three metrics; units come from the metric keys. An empty metric list shows outcomes and attempt counts, which is useful for a correctness or failure finding.

The renderer separates incompatible profiles and experimental lanes. It shows the tested client path, workload size, independent trial counts and uncertainty. It does not replace a failed latest attempt with an earlier successful speed estimate. Earlier failed trials remain visible even after a successful retry.

Confirmed explanations require direct accounting or a controlled experiment. Supported hypotheses and unexplained observations must name a next experiment. A product's architecture alone does not establish the cause of a timing difference.

An optional `chart` record contains `path`, `alt` and `caption`. Its local file must also appear in the annotation's evidence list. Use a chart that states units, workload, profile, independent trial counts and uncertainty; the renderer cannot establish those claims from the image.

For the three-attempt collection, export a selected finding with `bun scripts/export-finding-chart.ts CAMPAIGN.json ANNOTATION_ID CHART-DATA.json`, then use a Python environment with Matplotlib to run `python scripts/render-finding-chart.py CHART-DATA.json CHART.svg`. These commands refuse incomplete campaigns and existing outputs. The exporter reuses the tables' grouping and summary rules. The chart shows individual trial values, medians and observed ranges, with no confidence intervals. Failed latest attempts retain their status without an earlier timing estimate. Include the data, generated receipt and SVG in the annotation's evidence; inspect the PNG preview before publishing. The corrected publication has four visually reviewed figures, including unsuccessful startup profiles. Charts replace their main-page tables; the companion retains exact values.

## Select and publish

Set `report.findingIds` to three to five distinct annotation IDs, in reading order. Unselected annotations remain in the companion. Publication rejects an incomplete selection or a selected finding without its question, table or complete result bindings.

After the [publication checks](./methodology.md#provenance-and-publication) pass, prepare an assets directory containing the reviewed charts, investigation evidence and linked documentation at their report-relative paths. Include each investigation's supporting files, not only its summary JSON. All Markdown links must resolve within the prepared publication; the packager rejects missing files and symlinks.

Package a self-contained methods summary for readers at `docs/methodology.md`. It must describe the actual contracts, comparison rules, measurement limits and provenance checks. Keep the repository's development history separate: copying every linked implementation log and smoke campaign into each component report duplicates unrelated evidence. This does not permit omitting the raw data, source records, recovery evidence or experiment files supporting a published claim.

Publish into a new directory whose parent already exists:

```sh
bun scripts/publish-results.ts \
  --campaign .results/<campaign-id>/CAMPAIGN.json \
  --assets .tmp/publication-assets \
  --output .tmp/publication-ready
```

The command runs the full publication gate, compresses original artifacts, restores them elsewhere, and regenerates the reviewed report. It requires byte-identical regenerated Markdown and manifest output before making the destination available. Failures retain their temporary files for inspection. The assets and output directories must be separate; existing output directories are refused.

The resulting `RESULTS.json` is a compact index. Complete raw metadata and annotations remain in the compressed manifest. `ARCHIVE.json` records original and compressed checksums, and `README-ARCHIVE.md` explains restoration. Readable report links target the packaged evidence. Archived result logs are included by Git. Inspect the rendered output and verify the final staged artifact inventory before copying it into the repository or pushing it.

`bun run results:md -- --campaign <restored-publication>/RESULTS.json` remains available for regenerating uncompressed reports in the repository root. Evidence paths must resolve there when using that command.

## Assemble the corrected collection

Keep the SQL and Zero campaigns as separately validated and packaged reports. Build the full-roster coverage inventory from their completed working manifests with `bun scripts/build-publication-coverage.ts SQL_MANIFEST OUTPUT_DIRECTORY ZERO_MANIFEST`. It also incorporates the hash-bound retained-history catalog; it never combines timing samples. Replacement cases remain pending until all three attempts are recorded, and earlier failures remain visible.

Use `bun scripts/render-publication-summary.ts SUMMARY.json OUTPUT.md` for the main page. Its version-1 configuration has kind `source-separated-publication-summary`, two `sources` (`tuned-sql` and `tuned-zero`), and three to five `findings` selected from their reviewed reports. Each source supplies its `label`, report-relative `root`, packaged `manifest` path, uncompressed `manifestSha256` and `archiveSha256` for that component’s `ARCHIVE.json`. Use the compressed full manifest identified by the archive index. Each finding names its `source` and `annotation`. Set `presentation` to `essential-v1` for the short reader-facing page; omitting it reproduces the original detailed presentation. Keep `COVERAGE.json` and the summary configuration beside the output report. Bind `coverage`, `coverageSha256`, `coverageMarkdown` and `coverageMarkdownSha256` to the completed inventory.

The assembler checks source and trial bindings and regenerates coverage from recorded outcomes before using the supplied Markdown. Each finding table stays within its campaign. This rendering step does not replace component packaging, link checks, chart inspection or the final artifact audit. The observed-range formatting patch must be applied after collection and before publishing the three-attempt reports.

The original native campaign stopped after the query/index validity review. The [interim report](../results/history/2026-09-09-withdrawn-interim/RESULTS.md) is withdrawn as a tuned comparison; [three-attempt replacements](./implementation/query-index-correction.md) cover affected configurations only. The [corrected report](../RESULTS.md) summarizes both completed campaigns with compact tables and adjacent caveats. Both component packages passed full publication validation, restoration and byte-identical regeneration; [publication receipts](../results/diagnostics/final-publication/SQL-PUBLICATION.json) retain the checks. Future distributions must repeat these gates and preserve every linked artifact.
