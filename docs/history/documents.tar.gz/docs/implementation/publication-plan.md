# Corrected publication plan

Run **three attempts per changed case, including failures**, using Syncular JS and Rust 0.17.0. The September 8 user instruction supersedes the original ten-round decision. Keep the [original declaration](../../results/diagnostics/native-publication-declaration/DECLARATION.json) and pilot as historical evidence; their samples do not enter the corrected comparison.

## Collection

The two fixed campaigns contain 174 attempts:

| Campaign | Scope | Attempts |
| --- | --- | --- |
| [Tuned SQL](../../campaigns/publication-tuned-sql.json) | Syncular JS/Rust, PowerSync and Turso; fourteen cases each | 168 |
| [Native Zero screens](../../campaigns/publication-tuned-zero.json) | Local and relationship screens | 6 |

The [correction plan](./query-index-correction.md) explains the indexes and query paths. All ten screen preflight cases passed before publication began. Index maintenance affects ingestion and writes, so the SQL replacements cover every case. Zero replacements cover its two changed screen cases.

Retain Electric, Electric + TanStack DB, experimental Jazz and unaffected Zero coverage from the original campaign, labeled as historical. Browser and packet-network diagnostics remain separate profiles; single diagnostic attempts are not performance comparisons. Keep the eight-product roster and all failed, unsupported and unimplemented outcomes visible.

Use the declared seeded order, fresh client processes, unchanged source and configuration, and the fixed 20-second recovery outage. Do not pool campaigns, append favorable retries or change the sample count after inspecting results. Record interruptions and storage maintenance. Preserved server history and OS caches are environmental limits, even when a fixture resets correctly.

## Interpretation

Show each metric's independent-trial median and observed range. Three attempts cannot support the declared confidence intervals; retain the five-success threshold for intervals in eligible historical studies. Operation samples and multiple startup conditions are not additional independent campaign trials. A failed latest attempt supplies no successful latency estimate, and earlier failures remain visible.

Describe a latency difference as practically meaningful only when it exceeds **both 20% and the applicable absolute threshold**:

| Application question | Absolute threshold |
| --- | --- |
| Loaded local screen or local write acknowledgment | 1 ms |
| Server acceptance or another client's visibility | 5 ms |
| First screen, full dataset or replica reopening | 100 ms |
| Offline convergence, client recovery or access convergence | 100 ms |
| Attachment completion | 100 ms |

These are editorial conventions for this benchmark. Smaller differences can be reported numerically without a superiority claim. Ranges describe observed variability, not statistical significance. Correctness failures, unavailable guarantees and differing conflict outcomes need no latency threshold to merit a finding. Resource or traffic findings need an application consequence and a clearly stated measurement scope.

## Publication

Select three to five findings after reviewing the completed collection. Bind each finding to every attempt for its case, including failures. Explain the application question, observation, practical implication and evidence status. Confirmed causes require direct accounting or a controlled experiment; hypotheses and unexplained observations need a next experiment. Do not infer a cause from product architecture alone.

The September 9 reader simplification supersedes the original 1,000–1,500-word presentation. Keep the main page around 300–800 words: a plain explanation, compact result tables, caveats beside the numbers, and links to complete coverage and details. Charts, full annotations and audit evidence stay in the linked reports. Avoid an overall product score.

Follow the [reporting guide](../reporting.md): validate both terminal campaigns, verify all screen results, apply the prepared range-format patch, review annotations and charts, package and restore the evidence, and regenerate the report. Finish with a requirement-by-requirement RFC audit. Collection completion alone does not establish publication readiness.
