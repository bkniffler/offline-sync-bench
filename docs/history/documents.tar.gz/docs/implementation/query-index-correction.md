# Query and index correction

The 2026-09-07 campaign stopped after 470 attempts. Its 270-attempt interim report is withdrawn as a tuned product comparison. Raw measurements remain historical evidence. Exact output validation did not establish index suitability or a representative native query path; those checks were missing before collection.

On 2026-09-08 the user requested published Syncular JS/Rust **0.17.0** and changed the target to **three independent attempts per case**, including failures. This supersedes the ten-round and subsequent five-round decisions. With three attempts, report medians and ranges only; do not lower the five-success threshold for confidence intervals. Do not pool old and tuned results or add retries to improve an ordering.

## What changes

| Adapter | Correction | Replacement scope |
| --- | --- | --- |
| Syncular JS and Rust | Client indexes on `(project_id, owner_id, completed, id)` and `(project_id, id)` | All 14 cases; index maintenance affects ingestion and writes too |
| PowerSync | Composite expression indexes over its JSON-backed table, using the physical ID column | All 14 cases |
| Turso | The same composite indexes installed through the replicated schema | All 14 cases |
| Zero | Native local queries for filtering, ordering, limits and relationships; explicit application aggregation where used | Local and relationship screens |

The list index follows its equality filters, then ID ordering. Its prefix also covers owner/completion aggregation. Project/ID supports ordered detail and prefix search. SQL prefix search uses explicit string bounds matching the canonical ASCII ID prefix. Both exact output equality and actual query plans are checked on the complete fixture.

PowerSync Node 1.0.0 maps a schema-declared indexed `id` to JSON, although the actual ID is a physical column. The harness installs explicit indexes matching its generated view expressions and physical ID before connecting. This uses a version-bound storage layout and fails if that layout changes; it does not replace PowerSync replication or its query views. The captured initial schema documents the mismatch.

The SQL dashboard aggregates tasks once by project before joining project/organization labels. This avoids repeated scans through PowerSync’s JSON views for each project. The SDK reader pool is explicitly refreshed after index creation so all connections use the new schema.

Each SQL screen attempt now records `EXPLAIN QUERY PLAN` from its own replica before timing. Missing indexed access or a temporary sort for list/search/detail fails preparation. Dashboard aggregation can legitimately require grouping and sorting; an index declaration alone is not evidence of execution quality. Indexes exist before ingest so maintenance is included in startup and write measurements.

Zero list/search/detail no longer call the benchmark's array reference implementation. Aggregate and dashboard still include JavaScript grouping or reduction and are labelled accordingly. Electric's array path remains an application-processing baseline; it must not be presented as a native query-engine score. TanStack and Jazz already declare relevant native indexes; this correction does not establish that their query strategies are optimal.

## Bounded restart

The [tuned 0.17.0 preflight](../../results/diagnostics/tuned-v017-preflight/README.md) completed all ten cases on 2026-09-09. Its [review](../../results/diagnostics/publication-index-review/PREFLIGHT-REVIEW.json) checks recorded versions, complete fixture/output digest agreement and actual SQL query plans. Publication collection started after that gate passed.

Run the ten-case screen smoke check first: five changed adapters, two screen cases each. Inspect every result and the actual SQL plans. Then run two separately declared publication campaigns: four SQL adapters × 14 cases × three attempts = **168**, and Zero × two screen cases × three attempts = **6**. Smoke measurements do not contribute to publication counts.

Preserve Electric, TanStack and Jazz measurements and unaffected Zero cases separately. Do not rerun them for this correction. Their original campaign did not finish; retained cases with fewer than five successful attempts have no confidence interval. No mixed-source report may silently treat the withdrawn campaign as complete.

The root report and JSON now point to the corrected publication. The withdrawn comparison stays in its historical archive. The archived 270-attempt snapshot remains immutable; its earlier checks establish artifact integrity, not benchmark validity.

The withdrawn 470-attempt working directory is now [losslessly archived](../../results/history/2026-09-07-withdrawn-campaign/README.md); all 946 files were hash-verified before removing the uncompressed copy. The base campaign runner checks for 2 GiB of host filesystem headroom; the recovered SQL controller requires 7 GiB before each remaining attempt. The [recorded recoveries](../../results/diagnostics/tuned-v017-recovery/gap-0079/RECOVERY.json) preserve earlier failures and the original trial plan. Neither threshold guarantees that a whole campaign fits.

## Fixture storage maintenance

The first measured 0.17.0 preflight passed Syncular's local screens, then Turso failed with a native “no storage space” error. The host was nearly full. Its [failure record](../../results/diagnostics/publication-index-review/turso-checkpoint/FAILED-PREFLIGHT.json) preserves both attempts and the storage observations; Turso's measured volume growth does not account for the entire host free-space drop. No publication attempt started.

Turso's long-lived admin replica had a 5.2 GB WAL. A [native SDK checkpoint](../../results/diagnostics/publication-index-review/turso-checkpoint/CHECKPOINT.json) reduced that WAL to zero, preserving the observed task count and sync revision. The fixture service now checkpoints after reset and after pushing the seed, outside client timing. This changes fixture preparation and requires a new source-bound preflight; count equality alone is not sufficient validation. This checkpoints only the admin replica; it retains server history and leaves the measured client code unchanged.

The separate 6 GB failed-reset replica is [archived with every file hash verified](../../results/history/2026-09-09-turso-failed-reset/README.md). Only its uncompressed copy was removed. Retired Rust build intermediates were also removed; executable bytes and build receipts remain intact. These storage corrections recover capacity without discarding historical measurements or silently resetting the server's physical history.
