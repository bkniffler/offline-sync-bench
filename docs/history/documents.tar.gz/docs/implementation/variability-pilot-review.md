# Variability pilot review

**Historical decision:** the later user instruction capped corrected collection at three attempts per case, including failures. See the [current publication plan](./publication-plan.md). The ten-trial decision below remains part of the original campaign history.

The completed pilot selects **ten independent trials per case** for the first native publication. The [analysis](../../results/diagnostics/variability-pilot/ANALYSIS.json) applies the [rule declared before collection](../../results/diagnostics/variability-pilot-declaration/publication-plan.md): use ten trials if any fully observed primary metric has a range above 50% of its median and twice the applicable absolute threshold. Twenty-three metrics crossed both thresholds.

All 144 declared attempts finished: 134 passed, six timed out, one was invalid, and three were unsupported. Jazz startup and access revocation timed out in all three trials. PowerSync's third connected-fanout attempt was invalid during reader setup. Turso's tested profile remained unsupported for row-level access revocation. These outcomes stay in coverage; failed attempts supply no successful latency estimates.

The [verification](../../results/diagnostics/variability-pilot/VERIFICATION.json) checks the declaration, source, dependencies, configuration, Rust build, raw results, profiles and storage evidence. The [artifact check](../../results/diagnostics/variability-pilot/ARTIFACT-CHECKS.json) confirms all 294 campaign files, including 144 raw trials and their logs, match two copied locations. Reanalysis from the archived campaign reproduces the result, apart from its timestamp.

The [publication configuration](../../campaigns/publication.json) declares 1,120 attempts across eight native adapters and all fourteen cases, with a new seed. This decision is recorded before collection. The report and browser changes pass 321 regression tests, the canonical browser smoke passes its implemented cases, and the twenty-condition forwarding diagnostic is complete with verified artifacts. Publication will collect a fresh campaign under unchanged measured source.

This three-trial pilot provides no confidence intervals or product ranking. Missing and failed measurements remain unassessed, and the pilot does not estimate variability for every extension case. Ten trials are a fixed sampling decision, not a guarantee of precise estimates. Publication must report remaining uncertainty and must not pool these pilot samples with its own.
