# Rust build inputs and fresh artifact binding

The [native smoke](../../results/diagnostics/rust-build-inputs-smoke/VERIFICATION.json) now binds a fresh Rust executable to its dependency sources, native tools, SDK and controlled build recipe. Both the Rust collaboration workload and JavaScript control pass. These single-trial checks establish correctness and provenance; they do not estimate a language performance effect.

## What the build records

Each Rust campaign creates an empty owned target directory and runs a locked, offline release build for the recorded host target. It explicitly selects the compiler, native C/C++ tools, linker, archiver and SDK, disables compiler wrappers and ambient flags, and captures Cargo configuration. Cargo `[env]` overrides are rejected by this recipe because they can replace those selections. The user's shell environment is unchanged.

The metadata source inventory covers 110 packages, including build scripts, bundled SQLite and ring sources. The native inventory covers Rust's selected `bin` and `lib` directories, the Xcode toolchain, selected macOS SDK and named system tools. The original [discovery archive](../../results/diagnostics/rust-input-discovery/VERIFICATION.json) records 5,212 source files and 41,478 native files. Full bytes, modes, symlinks and root aliases are checked before/after the build and between campaign trials.

`RUST-BUILD.json` preserves the full inventories, controlled environment, Cargo configuration, dependency tree, actual compiler/build-script receipts and executable checksum. The manifest contains a compact identity. Publication validates the full record against the manifest and archived source, copies it to a fingerprinted directory and relocates its path without changing comparison identity. Custom binaries and legacy builds without this record remain ineligible for publication.

## Why the first verifier rejected a successful compilation

The [failed attempt](../../results/diagnostics/rust-build-development/VERIFICATION.json) contains 128 successful artifact receipts for 109 packages. The harness incorrectly required every metadata package and feature to appear in those receipts. Metadata included unused `zlib-rs` and extra `syn` features, so admission failed after compilation succeeded. The original failed build remains preserved and was not reused.

The corrected recipe captures `cargo tree` with normal/build edges in the same controlled environment. Every compiled package must belong to the source inventory and selected tree. Every tree package and its combined features must agree with actual compiler receipts. Reused artifacts, external output paths and missing packages are rejected. The fresh rerun confirms all 128 receipts and 109 compiled packages, while retaining the broader 110-package source inventory.

Cargo describes the [build-oriented tree](https://doc.rust-lang.org/cargo/commands/cargo-tree.html) as an approximation of compilation. This verifier requires agreement for the supported recipe; it does not assume universal equivalence. A future discrepancy fails admission and requires investigation.

## Verification and limits

The smoke archive verifies source, installed dependencies, runtime/service configuration, physical storage, raw outputs, result profiles and live executable bytes. Eleven deliberate corruptions are rejected, including cached/missing artifacts, changed features, external outputs, changed target/environment, mismatched executable identity and altered archived bytes. Relocated build records remain valid. The smoke is rejected as a performance publication. All 236 repository tests pass, with TypeScript and whitespace checks.

This machine selects Clang and related tools from Xcode while its SDK points to Command Line Tools. The SDK exists and its settings identify version 27.0; `xcrun --show-sdk-version` fails for that selection. The discovery archive preserves the error without claiming its cause. Apple's `ar` and `ranlib` reject `--version`; their exact bytes are inventoried with null version strings.

Native capture currently supports this macOS profile. Other platforms require declared toolchain/library roots. OS runtime libraries are identified by version/build rather than a copied system image. These records establish the captured recipe and artifact identity, not a hermetic or bit-for-bit reproducible build.
