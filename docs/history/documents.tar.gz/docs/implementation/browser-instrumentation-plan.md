# Loaded browser instrumentation experiment

Status: implemented; paired collection and artifact verification complete. This experiment remains separate from native publication and does not qualify browser performance comparisons by itself.

The entrypoint, condition controller, paired runner, provenance capture, analysis, process binding and configurations are applied. The full regression suite passes 321 tests. The [loaded smoke](../../results/diagnostics/browser-loaded-smoke/ARTIFACT-CHECKS.json) passes all four conditions, validates original and relocated artifacts, and rejects fifteen artifact corruptions. The [earlier smoke](../../results/diagnostics/browser-loaded-development/ARTIFACT-CHECKS.json) preserves a Zero setup failure that led to exact fixture readiness checks. The [canonical browser regression](../../results/diagnostics/browser-readiness-regression/VERIFICATION.json) passes both implemented collaboration cases, preserves four unimplemented cases, and verifies relocation.

All twenty declared instrumentation conditions completed successfully, giving five complete pairs per adapter. The [analysis](../../results/diagnostics/browser-loaded-instrumentation/ANALYSIS.json) and [artifact verification](../../results/diagnostics/browser-loaded-instrumentation/ARTIFACT-CHECKS.json) are archived with the declaration, source, raw records and logs. The [investigation](../investigations/browser-collaboration.md#loaded-forwarding-sensitivity) reports paired differences and their scope. Every reported interval includes zero; this imprecise sensitivity check does not establish negligible overhead or supply a correction factor for canonical timings.

## Question and intervention

Does forwarding native milestone receipts through CDP materially change the loaded collaboration workflow in the two implemented browser adapters, Electric and Zero?

The current entrypoint serializes native `local`, `accepted`, and `visible` events into the `benchReport` binding. The controller dispatches operations through CDP and observes these events. Existing calibration measures idle calls with small receipts. It cannot establish the cost of serializing and delivering actual native receipts during SDK work.

Use two diagnostic modes with the same native SDK calls, subscriptions, fresh stores, fixture, receipt validation and sequencing:

| Mode | Receipt handling |
| --- | --- |
| Buffered | Retain native event records in browser memory and retrieve them after the workload. |
| Forwarded | Retain the same records and also serialize/forward each through the existing CDP binding. |

Both modes must use identical controller completion signals. Add a diagnostic reader operation that waits for the armed native subscription match and resolves its CDP call. Start that wait before dispatching the write in both modes. Finish each operation only after the writer call and reader wait resolve. Forwarded bindings must not advance the diagnostic controller. This avoids comparing two different controller scheduling policies.

The intervention estimates the incremental effect of live milestone forwarding on this loaded diagnostic workflow. It does not measure all instrumentation overhead: both modes retain CDP dispatch/completion, buffered records, native observation and external resource sampling. The canonical binding-driven controller remains a different timing path, so this is not a correction factor for headline latency. Never subtract the estimate from benchmark samples.

## Fixed collection design

After implementation and correctness smoke, declare the exact source, browser bundle and experiment configuration before collecting measurements:

- Electric and Zero, using the existing inventoried Chromium installation and controlled local network profile.
- Five pairs per adapter, each pair containing one buffered and one forwarded trial. Use seed 20260924 to choose AB/BA order reproducibly before collection; archive the complete 20-attempt plan.
- Fresh writer/reader browser processes and user-data directories for every condition; reseed the same canonical 200-task fixture. Preserve service and physical-storage preparation records.
- Five warmups followed by 50 sequential measured writes. A 300-second whole-attempt deadline retains failure evidence and cleanup records. Every planned attempt runs once; no favorable retries or extra samples.
- Keep fatal-error reporting and lifecycle handling identical. Only native milestone forwarding changes between conditions. Retrieve buffered events after measurement and record exact payload sizes/received forwarded event counts.

The controller's monotonic per-operation span covers reader arming, write dispatch and both completion calls in both modes. Browser-local writer spans may separately describe local/server settlement from that writer's operation start. Do not subtract timestamps from different browser processes or the controller. Do not present overlapping phases as an additive breakdown.

## Verification and interpretation

Require exact initial/final datasets for both clients, all 55 ordered writes, expected native receipts, zero dropped or duplicate events, distinct process/store identities, and observed owned-process cleanup. Confirm every buffered event exists in both modes and every forwarded event matches its buffered record in forwarded mode. Buffered mode must have no forwarded native milestone events; fatal/lifecycle events remain separate.

Add focused corruption tests for missing receipts, mismatched titles, mode leakage, controller completion driven by forwarded bindings, nonmonotonic timing and incomplete cleanup. Verify that canonical collaboration retains its existing default behavior and evidence contract. Keep diagnostic results out of publication profile groups.

For each complete pair, compare trial medians for the common controller span and available writer-local spans. Retain all operation values and pair differences. With five complete pairs, report the median paired difference, range, and a clearly labeled bootstrap interval over pairs; with fewer, leave the interval unavailable. Preserve missing/failed pairs. Treat this as a bounded sensitivity check, not proof that all overhead is negligible or a powered equivalence test. Record both absolute differences and relative changes with the applicable baseline.

Archive raw records, source/dependencies/configuration/browser identities, the declared plan, analysis source, verification, and the scope above. Browser performance publication still requires its own independent repeated campaign after this check.
