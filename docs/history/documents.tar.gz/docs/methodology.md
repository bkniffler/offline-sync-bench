# Methodology

The benchmark implements [RFC 0001](./rfcs/0001-meaningful-comparisons-and-explainable-results.md). The [implementation record](./implementation/rfc-0001.md) distinguishes verified work from remaining coverage. Historical reports predate these contracts and remain [archived](../results/history/2026-09-05/README.md).

## Comparable workloads

A performance comparison requires the same application outcome, fixture, timing boundaries, network conditions, and required guarantees. Each adapter records its storage and query execution model. Browser and native-host profiles are separate, and Jazz v2 remains in an experimental lane.

The current `screens-v2` contract covers 100,000 local tasks: one project for task screens, and four projects for relationship screens. Before timing, it checks every task's identity, organization, project, owner, title, completed state and version, plus the related project and organization records. It checks exact query outputs outside each timed operation and retains output digests. Publication recomputes the expected fixture/output digests and verifies p50/p95 summaries against the stored samples; an arbitrary digest string or plausible aggregate cannot pass.

| Screen | Required output |
| --- | --- |
| Task list | 50 incomplete tasks assigned to user 2 in project 1, ordered by descending task ID; ID, title and completed state |
| Prefix search | First 100 project-1 task IDs with the `task-00` prefix, ordered by ID; ID and title |
| Task aggregate | Counts by owner and completed state, ordered by owner then completed state |
| Organization dashboard | Per-project total, completed and open task counts, ordered by open count descending then project ID |
| Project detail | First 100 project-1 tasks by ID, with task title and parent project/organization names |

Task IDs express deterministic seed order. These screens do not compare timestamp conversion or timestamp ordering. SQL, reactive queries and application-side array processing are labelled separately. Library-owned result metadata is explicitly normalized without dropping required application fields.

The `collaboration-v2` contract validates 200 initial tasks and separates local commit, client-observed server acceptance and independent reader visibility. It runs five warmups and 50 measured title updates. Adapters describe the exact write receipt and reader observation path; unavailable local receipts remain null.

The `offline-recovery-v2` contract uses 2,000 tasks, client-only network interruption, an independent reader, and complete data checks. It separates queue drain from reader visibility and adds SIGKILL/reopen with 1,000 persisted writes. The [recovery specification](./scenarios/offline-replay.md) records current coverage, cache and queue persistence, queue ownership, timing and native counter interpretation. Recovery now declares a fixed block-to-restoration duration (20 seconds by default), requires all offline checks before that deadline, and records controller-clock TCP events through replay. Missed readiness or excessive scheduling lateness invalidates the attempt. Different durations create different comparison profiles; native retry behavior remains part of the tested implementation. These guarantees determine comparison groups; a persisted cache alone cannot establish durable queued writes.

The `conflicting-edits-v1` contract verifies a stale update against a peer update or deletion. A third client confirms the peer operation before reconnect, and the declared policy determines the expected winner and native response. [Conflict cases](./scenarios/conflicting-edits.md) have separate profiles for different policies; queue drain alone is insufficient.

The [connected fanout](./scenarios/connected-fanout.md) and [reconnect-with-backlog](./scenarios/reconnect-storm.md) contracts use distinct reader processes and full 2,000-task validation. Fanout sends one update to live subscriptions; recovery verifies 100 server updates behind blocked reader routes before restoring them together. Per-client completion distributions do not substitute for independent campaign trials.

The [initial startup contract](./scenarios/bootstrap.md) measures product initialization, the first correct task screen and a full local snapshot at declared task counts, with 1k/10k/100k defaults and optional 500k/1m extensions. A restarted sync-service process and a second client against the warm service are separate cases; server volumes and OS caches are retained. Captured screen and snapshot values must pass exact validation.

Electric and Zero share a separate memory profile with SDK construction included in initialization and no persistence claim. Electric runs application queries over its SDK cache; Zero uses native full-task and filtered-screen views, both of which must complete. Full-snapshot validation normalizes enumeration order outside timing; the screen's ordering and projection remain strict. The [startup investigation](./investigations/electric-startup.md) preserves the ordering failure and its complete-data probe.

Electric + TanStack uses the file-backed profile. Its full-data receipt follows a complete native SQLite persistence scan; the captured persisted rows and active collection must both match the fixture. Native query readiness alone cannot certify that complete startup case.

Jazz uses a separate edge-durable seed process and fresh native SQLite readers in the experimental lane. Its screen queries are native; count observations materialize a native local query. The [startup investigation](./investigations/jazz-startup.md) preserves a 100k timeout and an extended diagnostic. A longer diagnostic deadline does not convert the canonical timeout into a successful trial. Startup failures retain partial progress, milestone receipts, traffic and scoped resource samples.

The [persisted-replica startup contract](./scenarios/replica-reopen.md) opens an existing 2,000-task product store in a fresh process with network access blocked. It separates initialization, first-screen availability and the full local snapshot. The OS file cache is not cleared; this does not substitute for cold network bootstrap.

The [access revocation contract](./scenarios/permission-change.md) checks exact same-client removal, preservation of authorized rows, offline cache behavior and fresh-client authorization. Online revoke timing and recovery after an offline revoke have distinct boundaries. Electric and Electric + TanStack use declared application refresh profiles. Explicit native purge, PowerSync continuous native purge, Zero native memory-cache purge, memory refresh and persisted-cache refresh render in separate comparison tables. PowerSync also checks the original SQLite file identity and uses a signed access-only grant with membership-derived buckets. Zero verifies both the underlying task cache and the active view, using a server-verified actor and native membership filter.

Jazz's native access profile also checks unscoped local task records, session-scoped queries and maintained subscriptions in the original SQLite runtime. Its two purge timeouts preserve full cache records, independent fresh-actor checks and native membership-revocation receipts. Failed outcomes remain visible and cannot supply successful latency comparisons.

The [attachment contract](./scenarios/blob-flow.md) validates two deterministic 2 MiB objects, every task and metadata field, native applied commits and queue states. Upload acknowledgment, server acceptance and independent reader visibility have separate clocks. Fresh-client downloads include a real 64 KiB response interruption followed by a verified full-object retry. Resource windows distinguish both-client upload work from each fresh download client.

Remaining adapter cases are ineligible for RFC comparisons until their contracts are implemented. A metric with the same name in a historical result is not sufficient evidence of compatibility.

## Trials and uncertainty

Campaign configuration declares the product/case matrix, repetitions, random seed, timeout, network profile and stopping rule before execution. Each case runs in a fresh process. Trials are randomized within repetition blocks and execute serially. Five warmups precede 25 measured operations for each screen.

### Browser profiles

Native-host is the default runtime. A Chromium campaign explicitly declares `runtime.kind`, `executable` and `installationRoot`; [the smoke configuration](../campaigns/browser-smoke.json) gives a machine-specific example. The harness inventories all files, modes and internal symlinks in that installation, builds one browser SDK bundle, and binds its inputs to the recorded source and installed dependencies. It checks those identities and the running browser version before accepting results. Published artifacts preserve the browser inventory and bundle alongside the manifest.

Browser collaboration is implemented for Electric's native memory Shape and Zero's native IndexedDB client. Each attempt has separate writer/reader browser processes and fresh profiles, complete initial/final task checks, native mutation receipts and independent subscription visibility. Other browser cases report not implemented; they never use a native-host adapter as a fallback. Browser campaigns currently accept only the local network profile.

The controller clock includes CDP reader arming, write dispatch and receipt delivery. Idle calibration is recorded before and after the workload, without subtracting it from measured latency. Resource samples include the controller and both browser process trees; summed RSS can double-count shared pages. OS and CDP process identities must agree, and cleanup checks all observed helpers. This is SDK collaboration rather than rendered UI timing, and configured IndexedDB does not establish restart durability. Browser results use a separate comparison key/lane from native-host results. The lane's stable/experimental designation describes the tested product, not Chromium's release channel. See the [verified browser investigation](./investigations/browser-collaboration.md).

### Network profiles

`local-loopback` keeps the original service routes and injects no delay or loss. Collaboration campaigns also support `private-veth-netem-v1`, which declares an immutable emulator image, one-way packet delay, random loss percentage, seed and queue limit. Both directional streams use the declared seed. Host port forwarding remains part of this profile; it does not represent a physical WAN connection.

The campaign controller creates two owned forwarding namespaces before starting the measured child and removes them after that child exits or times out. A private link segments traffic before impairment. Before/after records retain the actual queues, filters, NAT destinations, offload settings, packet-size counters and endpoint bindings. The child records the routes it received. Validation rejects mismatched routes, changed impairment, oversized packets and incomplete cleanup. Network configuration is part of the comparison key, so these results cannot aggregate with the original local profile.

Measured client traffic includes SDK connections, client authentication and application upload paths. Electric's collaboration mutation uses an explicit route and records acceptance from its validated response; fixture administration retains its original address. Its former follow-up-read boundary is excluded from revised acceptance comparisons. Native client initialization uses the same routed connection as later operations. Server-to-server callbacks retain their existing routes. Other suites, redirects, attachment URLs and browser coverage need their own integration before they can select this packet profile.

The [calibration investigation](./investigations/network-emulator-calibration.md) documents packet-unit checks and the distinction between connection setup and an established round trip. The [eight-adapter latency smoke](../results/diagnostics/network-collaboration-latency/VERIFICATION.json) passes complete collaboration and network validation at 50 ms each way. One trial per adapter establishes integration correctness; it does not estimate a performance difference or variability.

Publication requires at least three independent trials. Confidence intervals resample trial medians, not pooled operations. Fewer than five successful trials produce no interval. Interval width above 25% of the median is flagged as imprecise. The current replacement configuration is capped at three trials by user request; see docs/implementation/query-index-correction.md.

A timeout terminates the trial's process group and retains its status, elapsed time and log. Failed latest attempts remain failed. Earlier successes cannot substitute for them. Completed attempts with incompatible profiles cannot enter the same aggregate or cross-product comparison.

## Resources and transport

Screen resources are sampled by an external process over the measured process and its descendants. The sampling window begins after fixture validation and ends before client teardown. Baseline, time-weighted average, observed peak, retained RSS, CPU time and raw samples are retained. The sampler is excluded from the measured tree.

Jazz screen seeding runs in a separate process that confirms edge durability and exits before the measured reader starts with a new store. Both processes validate the same complete fixture digest. Every resource sample must include the reader and exclude the seeder and controller. Server state and OS caches remain shared; this isolation does not imply cold caches.

Process-tree RSS can double-count shared pages. Polling can miss short-lived children and brief peaks. CPU measurements use `ps` cumulative time with limited resolution; they do not establish precise short-interval CPU peaks.

The HTTP meter forwards response chunks as consumed and preserves cancellation. Request streaming is the default; transports requiring Content-Length use an explicit buffered-request compatibility path. These are payload-byte measurements, not whole-wire traffic. Native channels and WebSockets require their own instrumentation and cannot be represented by a misleading zero.

The [meter audit](../results/diagnostics/http-meter-audit.json) compares streamed and unmetered loopback transfers with identical payload validation. It describes that experiment's runtime and payload sizes, not universal instrumentation overhead.

## Server storage state

Campaigns retain existing server volumes and writable layers while each scenario prepares its logical fixture. They record Docker writable-layer bytes and allocated storage for every named volume and writable bind mount before and after each trial. Startup also records both boundaries around each client, after fixture preparation and service restart. Observation intervals must lie outside the declared workload window. Read-only configuration mounts are covered by the configuration artifact.

Mounted-path allocation comes from `du -sk`, converted from KiB to bytes. It describes allocated filesystem storage, not logical database contents, sync payload bytes or writable-layer deltas. Docker layer sizes and mount allocation have different scopes and are not summed. Missing counters retain a null value and an explicit reason. Container and mount identities must remain consistent and match the campaign configuration at publication.

These are live, non-atomic observations. Metadata traversal can warm filesystem caches; in-memory caches, deleted files held open by processes and OS cache residency are not measured by this inventory. The observations expose retained state without normalizing it or reconstructing prior workloads. The [Turso controlled experiment](./investigations/turso-startup-physical-state.md) demonstrates why this distinction matters: identical task data had different transfer and startup costs after a larger fixture.

The declared preparation and observation policy enters comparison profiles. Actual storage sizes remain per-trial evidence, so ordinary growth does not create a new profile for every sample. Complete records stay in raw artifacts; the report links to them instead of adding per-volume tables to the main page.

The corrected collection includes [documented disk maintenance and controller/daemon interruptions](./investigations/collection-interruptions.md). All saved attempts remain counted under the original plan. Recovery does not recreate uninterrupted cache, service or physical-storage conditions.

## Provenance and publication

`CAMPAIGN.json` records the source revision, dirty state, source/dependency file hashes, machine and runtime versions, container image IDs/resource limits, configuration, plan and every attempt. A source, image, installed dependency or captured runtime/service configuration change invalidates a running campaign. `CONFIGURATION.json` records resolved Compose settings, inspected container configuration, relevant runtime environment overrides and bind-mounted inputs. Named database volume contents remain separate physical-state evidence. A checksummed [source snapshot](./source-snapshots.md) preserves the exact file bytes, modes, links and deletions, including uncommitted changes. Publication verifies that archive, checks stored outcomes against the manifest, and requires explicit `--campaign` selection. Smoke and diagnostic runs cannot be published as performance comparisons.

Recovery after the Docker outage accepts one [verified serialization equivalence](./investigations/collection-interruptions.md#empty-dns-settings-after-docker-recovery): three absent DNS override fields in two Turso containers changed from `null` to `[]`. The original invalid manifest, observed configuration and equivalence proof are preserved. All other configuration checks remain enforced.

Coverage, implementation and outcomes are separate concepts. “Not implemented” describes this harness. “Unsupported in the tested configuration” requires an explicit reason. Invalid measurements, failures and timeouts remain visible. Missing telemetry stays unavailable.

Annotations bind to exact result IDs and hashes. Confirmed causes require direct accounting or a controlled experiment; supported hypotheses and unexplained observations name the next experiment. Evidence is linked from local artifacts shipped with the report. A changed result or configuration requires annotation review.

The [report authoring guide](./reporting.md) describes selection and table specifications. Publication requires three to five reviewed findings. The main page retains a compact suite overview, including all failed attempts and missing coverage; complete tables and all annotations are generated into `results/reports/<campaign-id>/DETAILS.md`. Selected tables bind every attempt for their case and keep incompatible profiles in separate groups.

[Deployment entrypoint footprint](./appendices/deployment-footprint.md) remains a separate appendix; it does not measure a complete working application.
