import { captureScreenPlans } from '../contracts/screen-indexes.ts';
import { preparePowerSyncFixture, takePowerSyncPreparations } from '../powersync-preparation.ts';
import { measureCollaboration, collaborationSeed, pollUntil } from '../contracts/collaboration.ts';
import { measureScreens, screenSeed, screenQueries, waitForScreenFixture, type ScreenCase, type Row } from '../contracts/screens.ts';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { join } from 'node:path';
import {
  PowerSyncDatabase,
  Schema,
  Table,
  column,
  type AbstractPowerSyncDatabase,
  type PowerSyncBackendConnector,
} from '@powersync/node';
import { createHttpMeter } from '../http-meter.ts';
import { tempRoot } from '../paths.ts';
import { getClientStack as getStack } from '../stacks.ts';
import type {
  BenchmarkStatus,
  JsonValue,
  TaskRecord,
} from '../types.ts';

interface RunnerResult {
  status: BenchmarkStatus;
  metrics: Record<string, number | null>;
  notes: string[];
  metadata: { [key: string]: JsonValue };
}

interface StackFixtures {
  sampleOrgId: string | null;
  sampleProjectId: string | null;
  sampleTaskId: string | null;
}

interface UploadBatchRequest {
  batch: Array<{
    op: 'PUT' | 'PATCH' | 'DELETE';
    table: string;
    id: string;
    data?: Record<string, string | number | boolean | null>;
  }>;
}

interface PowerSyncSession {
  db: PowerSyncDatabase;
  destroy: () => Promise<void>;
}

const acceptedWrites = new Map<string, () => void>();
const stack = getStack('powersync');
const scenario = process.argv[2];

export const AppSchema = new Schema({
  organizations: new Table({
    name: column.text,
  }),
  projects: new Table(
    {
      org_id: column.text,
      name: column.text,
    },
    {
      indexes: {
        org: ['org_id'],
      },
    }
  ),
  tasks: new Table(
    {
      org_id: column.text,
      project_id: column.text,
      owner_id: column.text,
      title: column.text,
      completed: column.integer,
      server_version: column.integer,
      updated_at: column.text,
    },
    {
      indexes: {},
    }
  ),
});

/** SDK 1.0.0 treats an indexed `id` as a JSON field, but IDs live in the
 * physical id column. Explicit expression indexes match the generated views
 * and the physical ID. They are installed before connecting or ingesting rows.
 * The pinned SDK layout is verified, and every screen records its actual plan. */
export async function installPowerSyncScreenIndexes(db: PowerSyncDatabase): Promise<void> {
  const columns = await db.getAll<{ name: string; type: string }>('PRAGMA table_info(ps_data__tasks)');
  if (!columns.some(c => c.name === 'id' && c.type === 'TEXT') || !columns.some(c => c.name === 'data' && c.type === 'TEXT')) throw new Error('PowerSync physical schema changed; review custom screen indexes');
  await db.execute("CREATE INDEX IF NOT EXISTS bench_tasks_list ON ps_data__tasks(CAST(json_extract(data, '$.project_id') AS TEXT), CAST(json_extract(data, '$.owner_id') AS TEXT), CAST(json_extract(data, '$.completed') AS INTEGER), id)");
  await db.execute("CREATE INDEX IF NOT EXISTS bench_tasks_project_id ON ps_data__tasks(CAST(json_extract(data, '$.project_id') AS TEXT), id)");
  // Refresh every reader in the SDK pool after custom DDL.
  await db.database.refreshSchema();
}

if (import.meta.main) {
if (
  scenario !== 'online-propagation' &&
  scenario !== 'local-query' &&
  scenario !== 'deep-relationship-query'
) {
  throw new Error(
    'Expected scenario argument: online-propagation | local-query | deep-relationship-query'
  );
}

try {
  const result = scenario === 'online-propagation' ? await runOnlinePropagation()
    : scenario === 'local-query' ? await runLocalQuery() : await runDeepRelationshipQuery();
  await writeResultAndExit(result);
} catch (error) {
  const { failureStatus } = await import('../execution.ts');
  await writeResultAndExit({ status: failureStatus(error), metrics: {}, notes: [String(error)],
    metadata: { fixturePreparation: takePowerSyncPreparations(),
      ...(error instanceof Error && 'evidence' in error ? { evidence: error.evidence as JsonValue } : {}) } });
}

}

export function createConnector(userId: string, endpoints: { appBaseUrl?: string; syncBaseUrl: string; accessNative?: boolean } = stack): PowerSyncBackendConnector {
  return {
    async fetchCredentials() {
      const response = await fetch(
        `${endpoints.appBaseUrl}/api/auth/token?user_id=${encodeURIComponent(userId)}${endpoints.accessNative ? '&profile=access' : ''}`
      );
      if (!response.ok) {
        throw new Error(
          `PowerSync token endpoint failed: ${response.status} ${response.statusText}`
        );
      }

      const body = (await response.json()) as { token: string };
      return {
        endpoint: endpoints.syncBaseUrl,
        token: body.token,
      };
    },

    async uploadData(database: AbstractPowerSyncDatabase): Promise<void> {
      const transaction = await database.getNextCrudTransaction();
      if (!transaction) {
        return;
      }

      const payload: UploadBatchRequest = {
        batch: transaction.crud.map((operation) => ({
          op: operation.op,
          table: operation.table,
          id: operation.id,
          data: operation.opData,
        })),
      };

      const response = await fetch(`${endpoints.appBaseUrl}/api/data`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(
          `PowerSync upload failed: ${response.status} ${response.statusText}`
        );
      }

      for (const operation of payload.batch) { const title = operation.data?.title; if (typeof title === 'string') acceptedWrites.get(title)?.(); }
      await transaction.complete();
    },
  };
}

async function runOnlinePropagation(): Promise<RunnerResult> {
  await waitForStackReady(); await seedStack(collaborationSeed);
  const fixtures = await getFixtures();
  if (!fixtures.sampleTaskId) throw new Error('PowerSync task fixture missing');
  const taskId = fixtures.sampleTaskId;
  const writer = await createSession('writer'), reader = await createSession('reader');
  try {
    await writer.db.waitForFirstSync(); await reader.db.waitForFirstSync();
    await waitForRowCount(writer.db, 200); await waitForRowCount(reader.db, 200);
    const result = await measureCollaboration({
      readData: () => reader.db.getAll<Row>('SELECT * FROM tasks'),
      localCommit: true,
      write: async (title, milestones) => {
        const accepted = new Promise<void>(resolve => acceptedWrites.set(title, () => { milestones.serverAccepted(); resolve(); }));
        try {
          await writer.db.execute('UPDATE tasks SET title = ? WHERE id = ?', [title, taskId]); milestones.localCommitted();
          await accepted;
        } finally { acceptedWrites.delete(title); }
      },
      observe: (title, signal) => pollUntil(async () => (await reader.db.getOptional<{ title: string }>('SELECT title FROM tasks WHERE id = ?', [taskId]))?.title === title, signal),
      diagnostics: { localCommit: 'local SQL execute completion', serverAccepted: 'successful upload response from mutation backend', reader: 'SDK continuous sync, 1ms local SQL polling', localStorage: 'powersync-node-sqlite-file' },
    });
    return { status: 'completed', ...result, metadata: { ...result.metadata, fixturePreparation: takePowerSyncPreparations(), implementation: 'powersync-collaboration-v2' } };
  } finally { acceptedWrites.clear(); await writer.destroy(); await reader.destroy(); }
}

async function runLocalQuery(): Promise<RunnerResult> { return runScreens('local-query'); }
async function runDeepRelationshipQuery(): Promise<RunnerResult> { return runScreens('deep-relationship-query'); }
async function runScreens(scenario: ScreenCase): Promise<RunnerResult> {
  await waitForStackReady();
  await seedStack(screenSeed(scenario));
  const session = await createSession(`powersync-${scenario}`);
  try {
    await session.db.waitForFirstSync();
    const readData = async () => ({ tasks: await session.db.getAll<Row>('SELECT * FROM tasks'), projects: await session.db.getAll<Row>('SELECT * FROM projects'), organizations: await session.db.getAll<Row>('SELECT * FROM organizations') });
    const fixtureReadiness = await waitForScreenFixture(scenario, readData);
    const result = await measureScreens(scenario, {
      execution: 'native-sql',
      readData,
      query: name => session.db.getAll<Row>(screenQueries[name]),
      diagnostics: { queries: screenQueries, localStorage: 'powersync-node-sqlite-file', queryPlans: await captureScreenPlans(scenario, sql => session.db.getAll<Row>(sql)) },
    });
    return { status: 'completed', ...result, metadata: { ...result.metadata, fixturePreparation: takePowerSyncPreparations(), fixtureReadiness, implementation: 'powersync-screens-v2' } };
  } finally { await session.destroy(); }
}

async function createSession(label: string): Promise<PowerSyncSession> {
  const dbPath = await createTempDbPath(label);
  const db = new PowerSyncDatabase({
    schema: AppSchema,
    database: {
      dbFilename: dbPath,
    },
  });

  await db.init();
  await installPowerSyncScreenIndexes(db);
  await db.connect(createConnector(label));

  return {
    db,
    destroy: async () => {
      try {
        await db.disconnect();
      } catch {
        // Ignore disconnect failures during cleanup.
      }
      await db.close();
      await rm(dbPath.replace(/\/[^/]+$/, ''), {
        recursive: true,
        force: true,
      });
    },
  };
}

async function createTempDbPath(prefix: string): Promise<string> {
  await mkdir(tempRoot, { recursive: true });
  const dir = await mkdtemp(join(tempRoot, `${prefix}-`));
  return join(dir, 'powersync.sqlite');
}

async function countRows(db: PowerSyncDatabase): Promise<number> {
  const row = await db.get<{ count: number | string }>(
    'select count(*) as count from tasks'
  );
  return Number(row.count);
}

async function waitForRowCount(
  db: PowerSyncDatabase,
  expectedRows: number,
  timeoutMs = 60_000
): Promise<number> {
  const startedAt = Date.now();

  while (Date.now() - startedAt < timeoutMs) {
    const rowsLoaded = await countRows(db);
    if (rowsLoaded === expectedRows) {
      return rowsLoaded;
    }
    await sleep(50);
  }

  const actualRows = await countRows(db);
  throw new Error(
    `PowerSync expected ${expectedRows} rows in local SQLite, got ${actualRows}`
  );
}

// The parent owns service provisioning and campaign identity. The native
// worker checks readiness without rebuilding services or deleting volumes.
async function waitForStackReady(): Promise<void> {
  await waitForUrl(`${stack.adminBaseUrl}/health`);
  await waitForUrl(`${stack.appBaseUrl}/health`);
  await waitForUrl(`${stack.syncBaseUrl}/probes/liveness`);
}

async function seedStack(options: {
  resetFirst: boolean;
  orgCount: number;
  projectsPerOrg: number;
  usersPerOrg: number;
  tasksPerProject: number;
  membershipsPerProject: number;
}): Promise<void> {
  const response = await fetch(`${stack.adminBaseUrl}/admin/seed`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
    },
    body: JSON.stringify(options),
  });

  if (!response.ok) {
    throw new Error(`PowerSync seed failed: ${response.status} ${response.statusText}`);
  }
  await response.json();
  await preparePowerSyncFixture();
}

async function getFixtures(): Promise<StackFixtures> {
  const response = await fetch(`${stack.adminBaseUrl}/admin/fixtures`);
  if (!response.ok) {
    throw new Error(
      `PowerSync fixtures failed: ${response.status} ${response.statusText}`
    );
  }
  return (await response.json()) as StackFixtures;
}

async function waitForUrl(url: string, timeoutMs = 60_000): Promise<void> {
  const startedAt = Date.now();
  let lastError = 'unreachable';

  while (Date.now() - startedAt < timeoutMs) {
    try {
      const response = await fetch(url);
      if (response.ok) {
        return;
      }
      lastError = `${response.status} ${response.statusText}`;
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error);
    }

    await sleep(250);
  }

  throw new Error(`Timed out waiting for ${url}: ${lastError}`);
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

async function writeResultAndExit(result: RunnerResult): Promise<never> {
  await new Promise<void>((resolve, reject) => {
    process.stdout.write(`${JSON.stringify(result)}\n`, (error) => {
      if (error) {
        reject(error);
        return;
      }
      resolve();
    });
  });

  process.exit(0);
}
