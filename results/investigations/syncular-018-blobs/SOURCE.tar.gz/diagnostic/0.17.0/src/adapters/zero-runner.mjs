import { measureCollaboration, collaborationSeed, pollUntil } from '../contracts/collaboration.ts';
import { measureScreens, screenSeed, screenProjectId, screenOwnerId, screenOrgId, taskRecord } from '../contracts/screens.ts';
import { SignJWT } from 'jose';
import { Zero } from '@rocicorp/zero';
import { mutators } from '../../services/zero-bench-app/src/mutators.ts';
import { schema, queries } from '../../services/zero-bench-app/src/schema.ts';
import { createHttpMeter } from '../http-meter.ts';
import { average, CpuSampler, MemorySampler, percentile, round } from '../metrics.ts';
import { ensureStackUp, getFixtures, seedStack } from '../stack-manager.ts';
import { getClientStack as getStack } from '../stacks.ts';

const stack = getStack('zero');
const zeroSecret = new TextEncoder().encode('benchsecret');
const scenario = process.argv[2];


if (
  scenario !== 'online-propagation' &&
  scenario !== 'local-query' &&
  scenario !== 'deep-relationship-query'
) {
  throw new Error(
    'Expected scenario argument: online-propagation | local-query | deep-relationship-query'
  );
}

const result =
  scenario === 'online-propagation'
      ? await runOnlinePropagation()
      : scenario === 'local-query'
          ? await runLocalQuery()
          : await runDeepRelationshipQuery();

await writeResultAndExit(result);

async function createAuthToken(userId) {
  return new SignJWT({})
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setSubject(userId)
    .setExpirationTime('10m')
    .sign(zeroSecret);
}

async function createZeroClient({ userId, storageKey }) {
  return new Zero({
    userID: userId,
    auth: await createAuthToken(userId),
    cacheURL: stack.syncBaseUrl,
    kvStore: 'mem',
    logLevel: 'error',
    schema,
    mutators,
    storageKey,
  });
}

async function waitForZeroRowCount({ zero, expectedRows, timeoutMs = 60_000 }) {
  const view = zero.materialize(queries.tasks.all());
  const startedAt = Date.now();
  try {
    while (Date.now() - startedAt < timeoutMs) {
      const rows = Array.from(view.data);
      if (rows.length === expectedRows) {
        return rows;
      }
      await Bun.sleep(50);
    }
  } finally {
    view.destroy();
  }

  throw new Error(`Zero did not reach ${expectedRows} rows before timeout`);
}

async function waitForZeroRelationshipData({
  zero,
  expectedOrgRows,
  expectedProjectRows,
  expectedTaskRows,
  timeoutMs = 120_000,
}) {
  const orgView = zero.materialize(queries.organizations.all());
  const projectView = zero.materialize(queries.projects.all());
  const taskView = zero.materialize(queries.tasks.all());
  const startedAt = Date.now();

  try {
    while (Date.now() - startedAt < timeoutMs) {
      const orgRows = Array.from(orgView.data);
      const projectRows = Array.from(projectView.data);
      const taskRows = Array.from(taskView.data);
      if (
        orgRows.length === expectedOrgRows &&
        projectRows.length === expectedProjectRows &&
        taskRows.length === expectedTaskRows
      ) {
        return {
          orgRows,
          projectRows,
          taskRows,
        };
      }
      await Bun.sleep(50);
    }
  } finally {
    orgView.destroy();
    projectView.destroy();
    taskView.destroy();
  }

  throw new Error(
    `Zero did not reach org/project/task counts ${expectedOrgRows}/${expectedProjectRows}/${expectedTaskRows} before timeout`
  );
}

async function waitForZeroTaskTitle({
  zero,
  taskId,
  expectedTitle,
  timeoutMs = 30_000,
}) {
  const view = zero.materialize(queries.tasks.all());
  const startedAt = Date.now();
  try {
    while (Date.now() - startedAt < timeoutMs) {
      const task = view.data.find((row) => row.id === taskId);
      if (task?.title === expectedTitle) {
        return;
      }
      await Bun.sleep(25);
    }
  } finally {
    view.destroy();
  }

  throw new Error(`Zero reader did not observe ${taskId}=${expectedTitle}`);
}

async function closeZero(zero) {
  await Promise.race([zero.close(), Bun.sleep(2_000).then(() => undefined)]);
}

async function runOnlinePropagation() {
  await ensureStackUp('zero'); await seedStack('zero', collaborationSeed);
  const fixtures = await getFixtures('zero');
  const writer = await createZeroClient({ userId: 'zero-writer', storageKey: 'writer' });
  const reader = await createZeroClient({ userId: 'zero-reader', storageKey: 'reader' });
  const view = reader.materialize(queries.tasks.all());
  try {
    await waitForZeroRowCount({ zero: writer, expectedRows: 200 });
    await waitForZeroRowCount({ zero: reader, expectedRows: 200 });
    const result = await measureCollaboration({
      readData: () => [...view.data],
      localCommit: true,
      write: async (title, milestones) => {
        const mutation = writer.mutate(mutators.tasks.update({ id: fixtures.sampleTaskId, title }));
        await Promise.all([
          mutation.client.then(result => { if (result.type !== 'success') throw new Error(`Local mutation failed: ${JSON.stringify(result)}`); milestones.localCommitted(); }),
          mutation.server.then(result => { if (result.type !== 'success') throw new Error(`Server mutation failed: ${JSON.stringify(result)}`); milestones.serverAccepted(); }),
        ]);
      },
      observe: (title, signal) => pollUntil(() => view.data.find(row => row.id === fixtures.sampleTaskId)?.title === title, signal),
      diagnostics: { localCommit: 'mutation.client', serverAccepted: 'mutation.server', reader: 'persistent local materialized view, 1ms polling', localStorage: 'zero-memory' },
    });
    return { status: 'completed', ...result, metadata: { ...result.metadata, implementation: 'zero-collaboration-v2', productVersion: writer.version } };
  } finally { view.destroy(); await closeZero(writer); await closeZero(reader); }
}

async function runLocalQuery() { return runScreens('local-query'); }
async function runDeepRelationshipQuery() { return runScreens('deep-relationship-query'); }
async function runScreens(scenario) {
  await ensureStackUp('zero');
  await seedStack('zero', screenSeed(scenario));
  const zero = await createZeroClient({ userId: `zero-${scenario}`, storageKey: scenario });
  const retained = [zero.materialize(queries.tasks.all()), ...(scenario === 'deep-relationship-query' ? [zero.materialize(queries.projects.all()), zero.materialize(queries.organizations.all())] : [])];
  try {
    let data;
    if (scenario === 'local-query') {
      data = { tasks: (await waitForZeroRowCount({ zero, expectedRows: 100_000, timeoutMs: 120_000 })).map(taskRecord) };
    } else {
      const { orgRows, projectRows, taskRows } = await waitForZeroRelationshipData({ zero, expectedOrgRows: 1, expectedProjectRows: 4, expectedTaskRows: 100_000, timeoutMs: 120_000 });
      data = { tasks: taskRows.map(taskRecord), projects: projectRows, organizations: orgRows };
    }
    const result = await measureScreens(scenario, {
      execution: 'mixed-native-and-application', readData: () => data,
      query: async name => {
        if (name === 'list') return (await zero.run(queries.tasks.startupScreen({ projectId: screenProjectId, ownerId: screenOwnerId }), { type: 'unknown' }))
          .map(row => ({ id: row.id, title: row.title, completed: Number(row.completed) }));
        if (name === 'search') return (await zero.run(queries.screens.search({ projectId: screenProjectId }), { type: 'unknown' }))
          .map(row => ({ id: row.id, title: row.title }));
        if (name === 'aggregate') {
          const rows = await zero.run(queries.screens.aggregate({ projectId: screenProjectId }), { type: 'unknown' });
          const groups = new Map();
          for (const row of rows) {
            const key = `${row.owner_id}:${Number(row.completed)}`;
            const group = groups.get(key) ?? { owner_id: row.owner_id, completed: Number(row.completed), task_count: 0 };
            group.task_count++; groups.set(key, group);
          }
          return [...groups.values()].sort((a, b) => (a.owner_id < b.owner_id ? -1 : a.owner_id > b.owner_id ? 1 : 0) || a.completed - b.completed);
        }
        if (name === 'detail_join') return (await zero.run(queries.screens.detail({ projectId: screenProjectId }), { type: 'unknown' }))
          .map(row => ({ id: row.id, title: row.title, project_name: row.project?.name, org_name: row.project?.organization?.name }));
        const projects = await zero.run(queries.screens.dashboard({ orgId: screenOrgId }), { type: 'unknown' });
        return projects.map(project => {
          const completed = project.tasks.reduce((count, task) => count + Number(task.completed), 0);
          return { org_name: project.organization?.name, project_id: project.id, project_name: project.name,
            task_count: project.tasks.length, completed_task_count: completed, open_task_count: project.tasks.length - completed };
        }).sort((a, b) => b.open_task_count - a.open_task_count || (a.project_id < b.project_id ? -1 : a.project_id > b.project_id ? 1 : 0)).slice(0, 20);
      },
      diagnostics: { localStorage: 'zero-memory', queryEngine: 'native Zero local one-shot queries over retained full-data subscriptions',
        queryExecutionByName: { list: 'native filter/order/limit plus projection', search: 'native range/order/limit plus projection',
          aggregate: 'native project filter plus JavaScript grouping/sort', detail_join: 'native relationships/order/limit plus projection',
          dashboard: 'native project filter and relationships plus JavaScript aggregate/sort/limit' },
        indexPolicy: 'Zero manages native query indexes; no application array scan for list/search/detail',
        timing: 'zero.run type=unknown plus output processing; query construction included, server completeness waits excluded' },
    });
    return { status: 'completed', ...result, metadata: { ...result.metadata, implementation: 'zero-native-screens-v3', productVersion: zero.version } };
  } finally { for (const view of retained) view.destroy(); await closeZero(zero); }
}

async function writeResultAndExit(result) {
  await new Promise((resolve, reject) => {
    process.stdout.write(`${JSON.stringify(result)}\n`, (error) => {
      if (error) {
        reject(error);
        return;
      }
      resolve(undefined);
    });
  });

  process.exit(0);
}
