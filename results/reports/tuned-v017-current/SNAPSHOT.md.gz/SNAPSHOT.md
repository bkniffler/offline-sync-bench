# Current measurements — provisional

Snapshot: **168/168 SQL attempts**, captured 2026-09-09T11:38:57.017Z. Collection status: **complete**. Three attempts maximum per case. Syncular JS/Rust 0.17.0. [Zero replacement screen measurements](../tuned-v017-zero-current/RESULTS.md) are recorded separately.

**Every timing below is milliseconds: median [observed minimum–maximum] across successful independent trials.** The pass/attempt column gives the actual count; incomplete cases are marked. These are observations, not the final reviewed findings or a confidence interval. Operation p50 values are summarized across trials, not pooled.

A dash means no eligible timing measurement, never zero. Failed latest attempts supply no timing estimate, even if an older attempt passed. Earlier failures remain counted. Distinct guarantee profiles have separate tables. Workload setup time is excluded from operation metrics where the contract specifies it; whole-attempt elapsed time is not operation latency.

[Full raw snapshot, including every saved result and its metadata](./CAMPAIGN.json.gz) · [Snapshot checks and hashes](./CHECKS.json) · [Full-roster coverage](../../diagnostics/publication-coverage/COVERAGE.md) · [Methodology](../../../docs/methodology.md) · [Failure explanations](../../../docs/investigations/tuned-publication-failures.md)

## Task screens · 100,000 tasks

Profile: stable native host; equivalent local screen output.

| Client / execution | Passed / attempted | Latest outcome | List p50 | Search p50 | Aggregate p50 |
| --- | --- | --- | --- | --- | --- |
| syncular / native-sql | 3/3 | completed | 0.020 [0.020–0.020] | 0.010 [0.010–0.010] | 3.88 [3.83–3.91] |
| syncular-rust / native-sql | 3/3 | completed | 0.020 [0.020–0.020] | 0.020 [0.020–0.020] | 3.54 [3.54–3.54] |
| powersync / native-sql | 3/3 | completed | 0.110 [0.100–0.360] | 0.110 [0.110–0.140] | 4.39 [4.21–5.29] |
| turso / native-sql | 3/3 | completed | 0.070 [0.060–0.070] | 0.100 [0.100–0.100] | 13.82 [13.67–13.84] |

## Relationship screens · 100,000 tasks

Profile: stable native host; equivalent local screen output.

| Client / execution | Passed / attempted | Latest outcome | Dashboard p50 | Detail p50 |
| --- | --- | --- | --- | --- |
| syncular / native-sql | 3/3 | completed | 5.20 [5.20–5.61] | 0.020 [0.020–0.020] |
| syncular-rust / native-sql | 3/3 | completed | 4.73 [4.54–4.90] | 0.040 [0.040–0.040] |
| powersync / native-sql | 3/3 | completed | 5.79 [5.60–6.00] | 0.170 [0.170–0.180] |
| turso / native-sql | 3/3 | completed | 23.58 [22.60–23.79] | 0.200 [0.200–0.200] |

## Collaboration · 200 tasks, 50 measured writes

Profile: stable native host; collaboration-v2.

| Client / execution | Passed / attempted | Latest outcome | Local commit p50 | Server accepted p50 | Reader visible p50 |
| --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-memory | 3/3 | completed | 0.110 [0.110–0.120] | 10.03 [9.29–10.35] | 6.22 [5.77–6.88] |
| syncular-rust / rusqlite-memory | 3/3 | completed | 0.150 [0.150–0.170] | 11.67 [9.56–12.18] | 7.31 [6.23–7.46] |
| powersync / powersync-node-sqlite-file | 3/3 | completed | 0.350 [0.270–0.400] | 322.8 [310.6–441.7] | 1005.1 [982.5–1014.1] |
| turso / turso-sqlite-file | 3/3 | completed | 0.120 [0.110–0.130] | 24.23 [23.68–24.45] | 25.93 [25.48–26.34] |

## Startup · 1,000 tasks

Profile: stable native host; fresh product file.

| Client / execution | Passed / attempted | Latest outcome | First screen (cold service) | Full data (cold service) | First screen (warm service) | Full data (warm service) |
| --- | --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 145.1 [120.6–145.9] | 145.5 [121.1–146.6] | 97.48 [95.81–106.3] | 97.96 [96.27–106.8] |
| syncular-rust / rusqlite-file | 3/3 | completed | 112.4 [109.9–120.6] | 105.6 [103.1–124.0] | 93.81 [90.30–108.7] | 86.83 [83.86–101.9] |
| turso / turso-file | 3/3 | completed | 3520.4 [2461.7–5344.6] | 3522.4 [2463.6–5346.7] | 3142.1 [2154.9–3431.3] | 3144.0 [2156.8–3433.4] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | First screen (cold service) | Full data (cold service) | First screen (warm service) | Full data (warm service) |
| --- | --- | --- | --- | --- | --- | --- |
| powersync / unspecified | 0/3 | timed-out | — | — | — | — |

## Startup · 10,000 tasks

Profile: stable native host; fresh product file.

| Client / execution | Passed / attempted | Latest outcome | First screen (cold service) | Full data (cold service) | First screen (warm service) | Full data (warm service) |
| --- | --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 198.3 [185.0–237.8] | 203.9 [189.1–243.6] | 121.4 [112.0–134.7] | 126.8 [115.3–140.4] |
| syncular-rust / rusqlite-file | 3/3 | completed | 265.3 [231.1–268.4] | 287.6 [224.2–289.6] | 150.5 [148.1–191.1] | 178.8 [144.3–210.4] |
| turso / turso-file | 3/3 | completed | 2560.7 [1805.2–3106.8] | 2579.5 [1826.0–3126.6] | 2743.6 [1572.5–2792.6] | 2761.7 [1591.3–2811.0] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | First screen (cold service) | Full data (cold service) | First screen (warm service) | Full data (warm service) |
| --- | --- | --- | --- | --- | --- | --- |
| powersync / unspecified | 0/3 | timed-out | — | — | — | — |

## Startup · 100,000 tasks

Profile: stable native host; fresh product file.

| Client / execution | Passed / attempted | Latest outcome | First screen (cold service) | Full data (cold service) | First screen (warm service) | Full data (warm service) |
| --- | --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 1277.2 [1071.8–1374.3] | 1309.7 [1102.2–1409.1] | 370.4 [363.4–467.4] | 404.0 [395.2–499.5] |
| syncular-rust / rusqlite-file | 3/3 | completed | 1649.2 [1612.0–2178.3] | 1643.1 [1605.1–2170.7] | 953.8 [925.7–1003.8] | 946.6 [917.9–1307.6] |
| turso / turso-file | 3/3 | completed | 2656.2 [2318.6–2955.4] | 2847.2 [2517.1–3168.8] | 2625.7 [2125.5–2912.4] | 2828.2 [2320.6–3109.3] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | First screen (cold service) | Full data (cold service) | First screen (warm service) | Full data (warm service) |
| --- | --- | --- | --- | --- | --- | --- |
| powersync / unspecified | 0/3 | timed-out | — | — | — | — |

## Offline replica reopen · 2,000 tasks

Profile: stable native host; existing product store, offline reopen.

| Client / execution | Passed / attempted | Latest outcome | Initialized | First screen | All rows |
| --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 52.86 [51.88–58.32] | 53.14 [52.15–58.70] | 55.48 [53.92–60.72] |
| syncular-rust / rusqlite-file | 3/3 | completed | 46.60 [46.06–49.39] | 46.89 [46.33–49.71] | 52.74 [52.19–56.19] |
| turso / turso-file | 2/3 | completed | 40.47 [34.90–46.04] | 40.95 [35.41–46.50] | 46.32 [40.93–51.70] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | Initialized | First screen | All rows |
| --- | --- | --- | --- | --- | --- |
| powersync / unspecified | 0/3 | timed-out | — | — | — |

## Offline replay · 10 queued writes

Profile: stable native host; product queue; persisted cache and queue; live replay; network restored after 20s outage.

| Client / execution | Passed / attempted | Latest outcome | Queue drained | Reader converged |
| --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 70.72 [69.01–81.99] | 71.79 [66.96–83.65] |
| syncular-rust / rusqlite-file | 3/3 | completed | 94.52 [59.05–131.5] | 97.18 [58.76–123.1] |
| turso / turso-file | 3/3 | completed | 43.04 [40.69–54.15] | 46.97 [45.70–72.18] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | Queue drained | Reader converged |
| --- | --- | --- | --- | --- |
| powersync / unspecified | 0/3 | invalid | — | — |

## Replay scaling · reader convergence

Profile: stable native host; product queue; persisted cache and queue; live replay; network restored after 20s outage.

| Client / execution | Passed / attempted | Latest outcome | 100 writes | 500 writes | 1,000 writes |
| --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 407.1 [296.5–432.8] | 1562.4 [1420.6–1651.1] | 2985.2 [2851.1–3268.0] |
| syncular-rust / rusqlite-file | 3/3 | completed | 394.4 [386.0–411.2] | 1603.5 [1402.9–3525.7] | 3058.4 [2670.3–3236.0] |
| turso / turso-file | 3/3 | completed | 35.63 [35.32–43.62] | 38.30 [35.07–51.37] | 92.48 [78.51–93.68] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | 100 writes | 500 writes | 1,000 writes |
| --- | --- | --- | --- | --- | --- |
| powersync / unspecified | 0/3 | invalid | — | — | — |

## Process crash and offline reopen · 1,000 queued writes

Profile: stable native host; product queue; persisted cache and queue; SIGKILL recovery; network restored after 20s outage.

| Client / execution | Passed / attempted | Latest outcome | Offline reopen | Queue drained | Reader converged |
| --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 56.35 [56.11–59.14] | 3422.0 [3282.9–3587.9] | 3368.3 [3236.5–3443.4] |
| syncular-rust / rusqlite-file | 3/3 | completed | 62.79 [60.36–63.49] | 3364.6 [3163.4–3554.6] | 3297.4 [3103.1–3490.2] |
| turso / turso-file | 3/3 | completed | 38.06 [34.70–44.55] | 77.64 [72.43–77.70] | 86.86 [83.96–87.51] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | Offline reopen | Queue drained | Reader converged |
| --- | --- | --- | --- | --- | --- |
| powersync / unspecified | 0/3 | invalid | — | — | — |

## Connected delivery · 2,000 tasks per reader

Profile: stable native host; product persisted cache; live delivery, no process-restart guarantee.

| Client / execution | Passed / attempted | Latest outcome | 5 readers | 25 readers |
| --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 16.43 [13.19–22.24] | 17.26 [16.53–17.90] |
| syncular-rust / rusqlite-file | 3/3 | completed | 16.50 [14.27–23.45] | 28.13 [16.29–37.53] |
| powersync / unavailable; no completed case | 0/3 | invalid | — | — |
| turso / turso-file | 2/3 | completed | 39.08 [35.61–42.55] | 534.5 [55.51–1013.4] |

## Reconnect · 100 updates accumulated behind blocked routes

Profile: stable native host; product persisted cache; live delivery, no process-restart guarantee.

| Client / execution | Passed / attempted | Latest outcome | 5 readers | 25 readers |
| --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 87.17 [83.01–145.2] | 291.6 [279.3–1141.0] |
| syncular-rust / rusqlite-file | 3/3 | completed | 78.96 [73.19–91.93] | 281.3 [273.7–683.4] |
| powersync / unavailable; no completed case | 0/3 | invalid | — | — |
| turso / turso-file | 2/3 | completed | 51.55 [50.11–53.00] | 119.5 [102.6–136.4] |

## Access revocation · separate guarantee profiles

Profile: stable native host; native purge.

| Client / execution | Passed / attempted | Latest outcome | Online removal | After reconnect |
| --- | --- | --- | --- | --- |
| syncular / syncular-persistent-file | 3/3 | completed | 14.25 [13.52–17.24] | 10.04 [9.80–11.67] |
| syncular-rust / syncular-rust-persistent-file | 3/3 | completed | 18.35 [17.35–31.38] | 13.30 [12.62–104.3] |

Profile: stable native host; native purge.

| Client / execution | Passed / attempted | Latest outcome | Online removal | After reconnect |
| --- | --- | --- | --- | --- |
| powersync / powersync-persistent-file | 3/3 | completed | 1057.2 [1001.9–2920.5] | 6496.8 [5126.1–8359.7] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | Online removal | After reconnect |
| --- | --- | --- | --- | --- |
| turso / unspecified | 0/3 | unsupported | — | — |

## Attachments · two 2 MiB objects

Profile: stable native host; attachments-v1.

| Client / execution | Passed / attempted | Latest outcome | Upload | Metadata visible | Fresh download | Interrupted download recovery |
| --- | --- | --- | --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | 30.53 [26.60–38.01] | 58.85 [41.77–60.77] | 28.57 [26.28–34.27] | 18.52 [16.76–20.32] |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | Upload | Metadata visible | Fresh download | Interrupted download recovery |
| --- | --- | --- | --- | --- | --- | --- |
| syncular-rust / unspecified | 0/3 | timed-out | — | — | — | — |
| powersync / unspecified | 0/3 | unsupported | — | — | — | — |
| turso / unspecified | 0/3 | unsupported | — | — | — | — |

## Update/update conflict · policy and outcome check

Profile: stable native host; conflicting-edits-v1.

| Client / execution | Passed / attempted | Latest outcome | Declared outcome |
| --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | reject-stale-update |
| syncular-rust / rusqlite-file | 3/3 | completed | reject-stale-update |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | Declared outcome |
| --- | --- | --- | --- |
| powersync / unspecified | 0/3 | invalid | last-arriving-patch |

Profile: stable native host; conflicting-edits-v1.

| Client / execution | Passed / attempted | Latest outcome | Declared outcome |
| --- | --- | --- | --- |
| turso / turso-file | 3/3 | completed | last-arriving-patch |

## Update/delete conflict · policy and outcome check

Profile: stable native host; conflicting-edits-v1.

| Client / execution | Passed / attempted | Latest outcome | Declared outcome |
| --- | --- | --- | --- |
| syncular / bun:sqlite-file | 3/3 | completed | delete-retained |
| syncular-rust / rusqlite-file | 3/3 | completed | delete-retained |

Profile: stable native host; unverified workload.

| Client / execution | Passed / attempted | Latest outcome | Declared outcome |
| --- | --- | --- | --- |
| powersync / unspecified | 0/3 | invalid | delete-retained |

Profile: stable native host; conflicting-edits-v1.

| Client / execution | Passed / attempted | Latest outcome | Declared outcome |
| --- | --- | --- | --- |
| turso / turso-file | 3/3 | completed | delete-retained |

## Status and evidence

Measured source: `8ecde51941dc281ad277fea9b6a28b7165e0c72cc9202d1fbb71c64201ca9a03`. This snapshot verifies the saved plan prefix, raw-result equality, per-result contracts and profile consistency. It does **not** pass the completed-campaign publication gate or replace final source/archive, annotation and chart review. Collection is complete. Final publication review remains pending.
