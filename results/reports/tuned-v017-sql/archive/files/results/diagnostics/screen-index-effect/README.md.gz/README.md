# Screen-index diagnostic

Six controlled SQLite attempts isolate the two added screen indexes. These are not product benchmark timings. Read the [investigation](../../../docs/investigations/screen-index-effect.md), [plan](./PLAN.json), [samples](./RESULTS.json), [verification](./VERIFICATION.json) and [chart](./index-effect.svg).
