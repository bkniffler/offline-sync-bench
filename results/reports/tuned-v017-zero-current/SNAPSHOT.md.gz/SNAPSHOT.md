# Current measurements — provisional

Snapshot: **6/6 Zero native-screen attempts**, captured 2026-09-09T11:38:57.392Z. Collection status: **complete**. Three attempts maximum per case. Native queries handle filtering, ordering and relationships; aggregation materializes rows and groups them in JavaScript. [SQL measurements](../tuned-v017-current/RESULTS.md) are recorded separately.

**Every timing below is milliseconds: median [observed minimum–maximum] across successful independent trials.** The pass/attempt column gives the actual count; incomplete cases are marked. These are observations, not the final reviewed findings or a confidence interval. Operation p50 values are summarized across trials, not pooled.

A dash means no eligible timing measurement, never zero. Failed latest attempts supply no timing estimate, even if an older attempt passed. Earlier failures remain counted. Distinct guarantee profiles have separate tables. Workload setup time is excluded from operation metrics where the contract specifies it; whole-attempt elapsed time is not operation latency.

[Full raw snapshot, including every saved result and its metadata](./CAMPAIGN.json.gz) · [Snapshot checks and hashes](./CHECKS.json) · [Full-roster coverage](../../diagnostics/publication-coverage/COVERAGE.md) · [Methodology](../../../docs/methodology.md) · [Failure explanations](../../../docs/investigations/tuned-publication-failures.md)

## Task screens · 100,000 tasks

Profile: stable native host; equivalent local screen output.

| Client / execution | Passed / attempted | Latest outcome | List p50 | Search p50 | Aggregate p50 |
| --- | --- | --- | --- | --- | --- |
| zero / mixed-native-and-application | 3/3 | completed | 0.110 [0.100–0.280] | 0.140 [0.080–0.230] | 63.87 [63.56–75.30] |

## Relationship screens · 100,000 tasks

Profile: stable native host; equivalent local screen output.

| Client / execution | Passed / attempted | Latest outcome | Dashboard p50 | Detail p50 |
| --- | --- | --- | --- | --- |
| zero / mixed-native-and-application | 3/3 | completed | 47.96 [46.82–51.73] | 0.210 [0.200–0.290] |

## Status and evidence

Measured source: `8ecde51941dc281ad277fea9b6a28b7165e0c72cc9202d1fbb71c64201ca9a03`. This snapshot verifies the saved plan prefix, raw-result equality, per-result contracts and profile consistency. It does **not** pass the completed-campaign publication gate or replace final source/archive, annotation and chart review. Collection is complete. Final publication review remains pending.
